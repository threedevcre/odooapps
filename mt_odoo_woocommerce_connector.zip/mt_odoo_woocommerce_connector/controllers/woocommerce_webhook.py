
import io
import json
from odoo import http
from odoo.http import Controller, route, request
from odoo.tools import html_escape
from odoo import fields, SUPERUSER_ID
from base64 import b64decode
from odoo.tools.image import image_data_uri, base64_to_image
import logging
from woocommerce import API


_logger = logging.getLogger(__name__)

                                                
class ImageController(http.Controller):        
    @http.route('/woocomm/images/<int:id>/<name>', type='http', auth='public', methods=['GET'], csrf=False)
    def get_woocomm_data(self, id, name):
               
        image = http.request.env['woocommerce.product.image'].sudo().search([('id', '=', id)], limit=1)
        raw_image = base64_to_image(image.wooc_image)
        
        return http.Response(response = b64decode(image.wooc_image.decode("utf-8")), 
                             status=200,
                             content_type=self.get_image_type(raw_image.format)
                             )
    
    def get_image_type(self, img_type):
        
        image_type = {
                    "JPEG"  : "image/jpeg",
                    "PNG"   : "image/png",
                    }
        if(image_type.__contains__(img_type)):
            return image_type[img_type]
        else:
            return "image/png"

    @http.route('/woocomm/sale_order_data', type='json', auth='public', methods=['POST'], csrf=False)
    def get_woocomm_sale_data(self, **post):
        try:
            data = json.loads(request.httprequest.data)
            print(data)
            _logger.info("Received WooCommerce order: %s", json.dumps(data, indent=2))
            all_instances = request.env['woocommerce.instance'].sudo().search([],limit=1)
            print(all_instances)
            woo_api = request.env['sale.order'].sudo().init_wc_api(all_instances)
            order = woo_api.get("orders/%s" % (str(data['order_id'])))
            print(order.json())
            print(data)
            order_response = order.json()
            order_data = order_response

            merged_order = {**order_data, **data}
            # Data keys overwrite order_data keys if conflicts exist
            _logger.info("Merged Order Data: %s", json.dumps(merged_order, indent=2))

            request.env['sale.order'].with_user(SUPERUSER_ID).create_sale_order(merged_order,all_instances)
            return  {"status": "success"}
        except Exception     as e:
            _logger.error("Webhook handling failed: %s", str(e))
            return {"status": "error", "message": str(e)}
