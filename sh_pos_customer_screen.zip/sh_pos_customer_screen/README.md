About
============
The customer screen shows you information about customers, like their taxes and discounts, and lets you show ads with pictures and messages. You can add new customers or give feedback. You can also write notes about customers, and you can put your logo on the screen. And there's a virtual keyboard to make typing easier. You also can show customer details, and customer notes on the screen.



Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list.
5) search module name and hit install button.

Any Problem with module?
=====================================
Please create your ticket here https://softhealer.com/support

Softhealer Technologies Doubt/Inquiry/Sales/Customization Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: support@softhealer.com
Website: https://softhealer.com
