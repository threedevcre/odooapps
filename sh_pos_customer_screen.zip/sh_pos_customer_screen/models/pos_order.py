# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import fields, models,api


class ShPosOrder(models.Model):
    _inherit = 'pos.order'


    # sh_order_rating = fields.Integer(string='Customer Rating')
    rating = fields.Selection([('0','0'),('1','1'),('2','2'),('3','3'),('4','4'),('5','5')])
    sh_order_feedback_message = fields.Char(string='Feedback')

    @api.model
    def _order_fields(self, ui_order):
        res = super(ShPosOrder, self)._order_fields(ui_order)
        # res['sh_order_rating'] = ui_order.get('sh_order_rating', False)
        if(ui_order.get('sh_order_rating')):
            res['rating'] = str(ui_order.get('sh_order_rating'))
        res['sh_order_feedback_message'] = ui_order.get('sh_order_feedback_message', False)
        return res