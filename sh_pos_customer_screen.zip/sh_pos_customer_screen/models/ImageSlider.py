# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import fields, models


class shImageSlider(models.Model):
    _name = 'sh.image.slider'

    name = fields.Char(string='Name')
    image = fields.Image(string="Image")
    sh_silder_image_id = fields.Many2one('pos.config')
    advertisement_image_id = fields.Many2one('pos.advertisement', ondelete='cascade')
    sh_image_title = fields.Char(string='Image Title')
