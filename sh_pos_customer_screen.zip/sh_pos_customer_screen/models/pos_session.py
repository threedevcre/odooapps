# Copyright (C) Softhealer Technologies.
# Part of Softhealer Technologies.
from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'

    # def _pos_data_process(self, loaded_data):
    #     loaded_data['sh_image_slider_by_id'] = {categ['id']: categ for categ in loaded_data['sh.image.slider']}
    #     loaded_data['sh_image_slider_timer'] = {categ['id']: categ for categ in loaded_data['sh.image.slider']}
    #     print("Loaded Data ----------------- ", loaded_data)
    #     super()._pos_data_process(loaded_data)

    def _pos_data_process(self, loaded_data):
        advertisements = self.env['pos.advertisement'].search([
            ('pos_id', 'in', self.config_id.ids)
        ])

        if advertisements:
            ad = advertisements[0]
            loaded_data['sh_image_slider_timer'] = ad.sh_image_slider_timer
            loaded_data['sh_image_slider_by_id'] = {img.id: img.read()[0] for img in ad.sh_slider_image_ids}
        else:
            loaded_data['sh_image_slider_timer'] = 3
            loaded_data['sh_image_slider_by_id'] = {}

        super()._pos_data_process(loaded_data)

    def _pos_ui_models_to_load(self):
        result = super()._pos_ui_models_to_load()
        if 'sh.image.slider' not in result:
            result.append('sh.image.slider')
        return result

    def _loader_params_sh_image_slider(self):
        return {'search_params': {'domain': [], 'fields': ['id'], 'load': False}}

    def _get_pos_ui_sh_image_slider(self, params):
        return self.env['sh.image.slider'].search_read(**params['search_params'])
