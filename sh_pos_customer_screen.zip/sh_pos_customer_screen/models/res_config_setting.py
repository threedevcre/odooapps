# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import  fields, models


class ShResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    
    sh_discount_details = fields.Boolean(related='pos_config_id.sh_discount_details',readonly=False)
    sh_tax_details  = fields.Boolean(related='pos_config_id.sh_tax_details',readonly=False)
    sh_customer_details  = fields.Boolean(related='pos_config_id.sh_customer_details',readonly=False)
    sh_customer_name = fields.Boolean(related='pos_config_id.sh_customer_name',readonly=False)
    sh_customer_mobile = fields.Boolean(related='pos_config_id.sh_customer_mobile',readonly=False)
    sh_customer_email = fields.Boolean(related='pos_config_id.sh_customer_email',readonly=False)
    sh_customer_address = fields.Boolean(related='pos_config_id.sh_customer_address',readonly=False)
    sh_customer_note = fields.Boolean(related='pos_config_id.sh_customer_note', readonly=False)
    sh_slider_image_ids = fields.One2many(related='pos_config_id.sh_slider_image_ids', readonly=False )
    sh_image_slider_timer = fields.Integer(related='pos_config_id.sh_image_slider_timer', readonly=False)
    sh_hide_odoo_logo = fields.Boolean(related='pos_config_id.sh_hide_odoo_logo', readonly=False)
    sh_advertisement_image = fields.Boolean(related='pos_config_id.sh_advertisement_image', readonly=False)
    sh_custom_logo = fields.Image(related='pos_config_id.sh_custom_logo', readonly=False)
    sh_customer_feedback = fields.Boolean(related='pos_config_id.sh_customer_feedback', readonly=False)
    sh_create_customer = fields.Boolean(related='pos_config_id.sh_create_customer', readonly=False)
    sh_virtual_keyboard = fields.Boolean(related='pos_config_id.sh_virtual_keyboard' ,readonly=False)
    sh_enable_advertisement_sentence = fields.Boolean(related='pos_config_id.sh_enable_advertisement_sentence', readonly=False)
    sh_advertisement_sentence = fields.Char(related='pos_config_id.sh_advertisement_sentence', readonly=False)
    pos_iface_customer_facing_display_local = fields.Boolean(related='pos_config_id.iface_customer_facing_display_local', readonly=False)
