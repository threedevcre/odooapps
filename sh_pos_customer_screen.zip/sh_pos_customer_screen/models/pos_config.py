# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import fields, models


class ShPosConfig(models.Model):
    _inherit = 'pos.config'

    sh_discount_details = fields.Boolean(string="Show Discount")
    sh_tax_details  = fields.Boolean(string="Show Taxes")
    sh_customer_details  = fields.Boolean(string="Show Customer Details")
    sh_customer_name = fields.Boolean(string="Customer Name")
    sh_customer_mobile = fields.Boolean(string="Customer Mobile")
    sh_customer_email = fields.Boolean(string="Customer Email")
    sh_customer_address = fields.Boolean(string="Customer Address")
    sh_customer_note = fields.Boolean(string="Show customer Note")
    sh_slider_image_ids = fields.One2many('sh.image.slider', 'sh_silder_image_id',string='Slider Image' )
    sh_image_slider_timer = fields.Integer(string='Image Slider Time')
    sh_hide_odoo_logo = fields.Boolean(string="Hide Odoo Logo")
    sh_advertisement_image = fields.Boolean(string="Advertisement Image")
    sh_custom_logo = fields.Image(string="Logo Image")
    sh_customer_feedback = fields.Boolean(string="Customer Feedback")
    sh_create_customer = fields.Boolean(string="Create Customer")
    sh_virtual_keyboard = fields.Boolean(string="Virtual Keyboard")
    sh_enable_advertisement_sentence = fields.Boolean(string="Enable Advertisement Sentence")
    sh_advertisement_sentence =  fields.Char(string="Advertisement Sentence")
    iface_customer_facing_display_local = fields.Boolean(string='Local Customer Facing Display',
                                                         help="Show checkout to customers.")