# -*- coding: utf-8 -*-
from odoo import api, fields, models


class POSAdvertisement(models.Model):
    _name = "pos.advertisement"

    # Source field (editable in form via the computed alias below)
    customer_display_bg_img = fields.Image(
        string="Background Image",
        max_width=1920,
        max_height=1920,
    )

    # Keep your original field name (used by your XML view)
    iface_customer_facing_display_background_image_1920 = fields.Image(
        string="Background Image",
        max_width=1920,
        max_height=1920,
        compute="_compute_iface_customer_facing_display_background_image_1920",
        inverse="_inverse_iface_customer_facing_display_background_image_1920",
        store=True,
    )

    pos_id = fields.Many2many("pos.config", string="POS")

    sh_enable_advertisement_sentence = fields.Boolean(string="Enable Advertisement Sentence")
    sh_advertisement_sentence = fields.Char(string="Advertisement Sentence")

    sh_discount_details = fields.Boolean(string="Show Discount")
    sh_tax_details = fields.Boolean(string="Show Taxes")

    sh_hide_odoo_logo = fields.Boolean(string="Add Custom Logo")
    sh_custom_logo = fields.Image(string="Logo Image")

    sh_advertisement_image = fields.Boolean(string="Advertisement Image")
    sh_image_slider_timer = fields.Integer(string="Image Slider Time")
    sh_slider_image_ids = fields.One2many(
        "sh.image.slider", "advertisement_image_id", string="Slider Image"
    )

    state = fields.Selection(
        selection=[("draft", "Draft"), ("applied", "Applied"), ("finish", "Finished")],
        string="Status",
        default="draft",
    )

    date = fields.Datetime("Date", default=fields.Datetime.now)

    # -----------------------------
    # Compute / Inverse (Fix crash)
    # -----------------------------
    @api.depends("customer_display_bg_img")
    def _compute_iface_customer_facing_display_background_image_1920(self):
        for rec in self:
            rec.iface_customer_facing_display_background_image_1920 = rec.customer_display_bg_img

    def _inverse_iface_customer_facing_display_background_image_1920(self):
        for rec in self:
            rec.customer_display_bg_img = rec.iface_customer_facing_display_background_image_1920

    # -----------------------------
    # Buttons (same behavior)
    # -----------------------------
    def button_draft(self):
        for rec in self:
            rec.remove_advertisement()
            rec.state = "draft"

    def button_apply(self):
        for rec in self:
            rec.state = "applied"

            # Your original logic is commented out.
            # Keeping it commented preserves your exact current behavior.

    def button_finish(self):
        for rec in self:
            rec.remove_advertisement()
            rec.state = "finish"

    def remove_advertisement(self):
        for rec in self:
            for pos in rec.pos_id:
                # These fields exist only if your module adds them on pos.config.
                # Keeping your code as-is, but mapping bg image to Odoo 19 core field.
                pos.iface_customer_facing_display_local = False

                # Odoo 19 core background image field:
                pos.customer_display_bg_img = False

                pos.sh_enable_advertisement_sentence = False
                pos.sh_advertisement_sentence = False
                pos.sh_discount_details = False
                pos.sh_tax_details = False
                pos.sh_hide_odoo_logo = False
                pos.sh_custom_logo = False
                pos.sh_advertisement_image = False
                pos.sh_image_slider_timer = False
                pos.sh_slider_image_ids = False
