# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
{
    "name": "Point Of Sale Customer Screen ",
    "author": "Softhealer Technologies",
    "website": "https://www.softhealer.com",
    "support": "support@softhealer.com",
    "category": "point of sale",
    "license": "OPL-1",

    "summary": "POS Customer Screen POS Customer Cart Screen POS Customer Review Screen POS Customer Product Screen POS Customer Details Screen POS Customer Logo on Screen POS Create Customer from POS Customer Screen Advertisement on POS Customer Screen Advertisement Images on POS Customer Screen Advertisement Sentences on POS Customer Screen Customer Notes on POS Customer Screen Customer Feedback From POS Customer Screen Vertual Keybord on POS Customer Screen Upgrade Your Business with Odoo POS Customer Screen Enhance Customer Experiences Point of Sale Customer Screen POS Cart Screen POS Display Kitchen Order Management Odoo Kitchen-Cart-Review Screens Pos Customer Cart Pos Customer Display Pos Multi Advertisement Images Display Pos Multiple Display Images Point Of Sale Customer Cart Screen Point Of Sale Customer Review Screen Point Of Sale Customer Product Screen Point Of Sale Customer Details Screen Point Of Sale Customer Logo on Screen Point Of Sale Create Customer from Point Of Sale Customer Screen Advertisement on Point Of Sale Customer Screen Advertisement Images on Point Of Sale Customer Screen Advertisement Sentences on Point Of Sale Customer Screen Customer Notes on Point Of Sale Customer Screen Customer Feedback From Point Of Sale Customer Screen Vertual Keybord on Point of Sale Customer Screen Upgrade Your Business with Odoo Point Of Sale Customer Screen Enhance Customer Experiences Point Of Sale Cart Screen Point Of Sale Display Kitchen Order Management Odoo Kitchen-Cart-Review Screens Point of Sale Customer Cart Point of Sale Customer Display Point of Sale Multi Advertisement Images Display Point of Sale Multiple Display Images Customer Notes Customer Details Customer Discounts Customer Taxes Customer Feedback Customer Order Custom Logo Advertisement Image Advertisement Sentences Advertisement Images Create Customer New Customer ",

    "description": """  The customer screen shows you information about customers, like their taxes and discounts, and lets you show ads with pictures and messages. You can add new customers or give feedback. You can also write notes about customers, and you can put your logo on the screen. And there's a virtual keyboard to make typing easier. You also can show customer details, and customer notes on the screen.""",

    "version": "0.0.1",
    "depends": ["point_of_sale"],
    "application": True,
    "data": [
        'security/ir.model.access.csv',
        'views/res_config_setting.xml',
        'views/pos_order_view.xml',
        'views/pos_advertisement_view.xml',
    ],

    'assets': {
        'point_of_sale._assets_pos': [
            'sh_pos_customer_screen/static/src/overrides/models/model.js',
            'sh_pos_customer_screen/static/src/overrides/components/customer_facing_display_button/customer_facing_display_button.js',
            'sh_pos_customer_screen/static/src/overrides/components/customer_facing_display_button/CustomerFacingDisplayOrder.xml',

            # 'sh_pos_customer_screen/static/src/js/payment_screen_patch.js',
            # 'sh_pos_customer_screen/static/src/js/paymet_screen_inherit.xml',

        ],
    },

    "auto_install": False,
    "installable": True,
    "images": ['static/description/background.png', ],
    "price": 78,
    "currency": "EUR"
}
