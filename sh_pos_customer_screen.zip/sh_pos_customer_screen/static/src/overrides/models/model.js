/** @odoo-module */

import { PosStore } from "@point_of_sale/app/store/pos_store";
import { Order } from "@point_of_sale/app/store/models/order";
import { Orderline } from "@point_of_sale/app/store/models/orderline";
import { patch } from "@web/core/utils/patch";

function formatNumberWithCommas(value) {
    const v = Number(value || 0);
    return Math.floor(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/* ============================================================
 * PosStore: load extra data
 * ============================================================ */
patch(PosStore.prototype, {
    async _processData(loadedData) {
        await super._processData(...arguments);
        this.sh_image_slider_by_id = loadedData["sh_image_slider_by_id"];
        this.config.sh_image_slider_timer = loadedData["sh_image_slider_timer"];
    },
});

/* ============================================================
 * Orderline helpers (Odoo 19 APIs)
 * ============================================================ */
patch(Orderline.prototype, {
    get_discount_amount() {
        const qty = this.getQuantity();
        return qty * ((this.price * this.discount) / 100);
    },

    get_tax_amount() {
        // Odoo19: getAllPrices() gives tax and priceWithTax
        const ap = this.getAllPrices();
        return ap?.tax ?? 0;
    },

    get_tax_percentage() {
        const taxIds = this.tax_ids || [];
        if (Array.isArray(taxIds) && taxIds.length) {
            const taxDetails = taxIds.map((id) => this.pos.taxes_by_id[id]).filter(Boolean);
            return taxDetails.reduce((total, tax) => total + (tax.amount || 0), 0);
        }
        return "0";
    },

    get_quantity_int() {
        return Math.floor(this.getQuantity());
    },

    get_formatted_price() {
        // qty * list price
        const qty = this.getQuantity();
        const lst = this.product_id?.lst_price || 0;
        return formatNumberWithCommas(qty * lst);
    },

    get_formatted_tax_amount() {
        return formatNumberWithCommas(this.get_tax_amount());
    },

    get_formatted_display_price() {
        const ap = this.getAllPrices();
        return formatNumberWithCommas(ap?.priceWithTax ?? 0);
    },

    get_formatted_discount_str() {
        const qty = this.getQuantity();
        const lst = this.product_id?.lst_price || 0;
        const ap = this.getAllPrices();
        const total = ap?.priceWithTax ?? 0;
        const discount = (qty * lst) - total;
        return formatNumberWithCommas(discount);
    },
});

/* ============================================================
 * Order helpers (Odoo 19 APIs)
 * ============================================================ */
patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
        this.sh_rating = 0;
        this.sh_feedback_messeage = "";
    },

    /* ----- Slider images (same behavior as Odoo17) ----- */
    get_slider_image() {
        return Object.values(this.pos.sh_image_slider_by_id || {});
    },

    /* ----- Feedback fields ----- */
    get_rating() {
        return this.sh_rating;
    },
    set_rating(rating) {
        this.sh_rating = rating;
    },

    get_feedback_message() {
        return this.sh_feedback_messeage;
    },
    set_feedback_message(message) {
        this.sh_feedback_messeage = message;
    },

    /* ----- Export to backend ----- */
    exportAsJSON() {
        const json = super.exportAsJSON(...arguments);
        if (this.get_rating() || this.get_feedback_message()) {
            json.sh_order_rating = this.get_rating();
            json.sh_order_feedback_message = this.get_feedback_message();
        }
        return json;
    },

    /* ----- Totals + formatting used by your XML ----- */
    get_total_quantity() {
        return this.getOrderlines().reduce((total, line) => {
            return line.product_id?.barcode !== "SRV-FEE" ? total + line.get_quantity_int() : total;
        }, 0);
    },

    get_subtotal() {
        const subtotal = this.getOrderlines().reduce((total, line) => {
            if (line.product_id?.barcode === "SRV-FEE") return total;
            return total + (line.getQuantity() * (line.product_id?.lst_price || 0));
        }, 0);
        return formatNumberWithCommas(subtotal);
    },

    get_selected_orderline() {
        return this.getOrderlines().find((l) => !!l.selected) || null;
    },

    get_formatted_total_with_tax() {
        return formatNumberWithCommas(this.getTotalWithTax());
    },

    get_formatted_get_total_tax() {
        // match Odoo19 receipt approach using taxTotals
        const taxTotals = this.taxTotals || {};
        let totalTax = 0;
        if (taxTotals.subtotals) {
            for (const subtotal of taxTotals.subtotals) {
                for (const group of subtotal.tax_groups || []) {
                    totalTax += group.tax_amount_currency || 0;
                }
            }
        } else {
            totalTax = this.getOrderlines().reduce((acc, l) => acc + (l.getAllPrices()?.tax || 0), 0);
        }
        return formatNumberWithCommas(totalTax);
    },

    get_formatted_total_discount_order() {
        const totalDiscount = this.getOrderlines().reduce((total, line) => {
            if (line.product_id?.barcode === "SRV-FEE") return total;
            const qty = line.getQuantity();
            const lst = line.product_id?.lst_price || 0;
            return total + ((qty * lst) - (qty * (line.price || 0)));
        }, 0);
        return formatNumberWithCommas(totalDiscount);
    },

    get_formatted_get_change() {
        // Odoo19 uses orderChange
        return formatNumberWithCommas(this.orderChange || 0);
    },

    get_paymentlines_formatted() {
        const pls = (this.payment_ids || []).filter((p) => !p.is_change);
        return pls.map((pl) => {
            const method = pl.payment_method || pl.payment_method_id;
            const type = method?.type || "";
            return {
                method:
                    type === "cash" ? "Cash" :
                    type === "bank" ? "Bank" :
                    "Customer Account",
                amount: formatNumberWithCommas(pl.getAmount ? pl.getAmount() : pl.amount),
            };
        });
    },
});
