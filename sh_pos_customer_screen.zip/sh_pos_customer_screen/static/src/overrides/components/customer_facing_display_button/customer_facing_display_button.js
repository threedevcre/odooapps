/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { Navbar } from "@point_of_sale/app/components/navbar/navbar";
import { CustomerDisplay } from "@point_of_sale/app/customer_display/customer_display";
import { CustomerDisplayPosAdapter } from "@point_of_sale/app/customer_display/customer_display_adapter";
import { useState, onMounted, onWillUnmount, useEffect } from "@odoo/owl";

const ACTION_CHANNEL = "CUSTOMER_DISPLAY_ACTION";

/* ============================================================
 * A) POS SIDE: actions from customer display -> POS
 * ============================================================ */
patch(Navbar.prototype, {
    setup() {
        super.setup(...arguments);

        // Install only once
        if (this._shCustomerDisplayActionChannel) return;

        this._shCustomerDisplayActionChannel = new BroadcastChannel(ACTION_CHANNEL);
        this._shCustomerDisplayActionChannel.onmessage = async (ev) => {
            const msg = ev.data || {};
            const pos = this.pos;

            const order = pos.getOrder?.() || pos.get_order?.();
            if (!order) return;

            switch (msg.type) {
                case "SUBMIT_FEEDBACK": {
                    const { rating = 0, message = "" } = msg.payload || {};
                    order.set_rating?.(rating);
                    order.set_feedback_message?.(message);
                    break;
                }

                case "CREATE_CUSTOMER": {
                    const payload = msg.payload || {};
                    if (!payload.name) return;

                    const partnerId = await pos.env.services.orm.call(
                        "res.partner",
                        "create_from_ui",
                        [payload]
                    );
                    await pos.load_new_partners?.();
                    const partner = pos.db.get_partner_by_id?.(partnerId);
                    if (partner) {
                        order.set_partner?.(partner);
                    }
                    break;
                }

                default:
                    break;
            }
        };
    },
});

/* ============================================================
 * B) POS SIDE: push extra data to customer display (adapter)
 * ============================================================ */
function _getCashier(pos) {
    // Odoo builds differ; try a few options.
    return pos.get_cashier?.() || pos.getCashier?.() || pos.user || null;
}

patch(CustomerDisplayPosAdapter.prototype, {
    dispatch(pos) {
        // screen name so display can behave differently in PaymentScreen
        this.data.screenName = pos.router?.state?.current || null;

        const order = pos.getOrder?.() || pos.get_order?.();

        // slider images + timer (from your config)
        this.data.sliderImages = order?.get_slider_image?.() || [];
        this.data.sliderTimerSec = pos.config?.sh_image_slider_timer || 3;

        // cashier box on display
        const cashier = _getCashier(pos);
        this.data.cashier = cashier ? { id: cashier.id, name: cashier.name } : null;

        // partner info (so your PaymentScreen “Hey <name>” can work like Odoo17)
        const partner = order?.getPartner?.() || order?.get_partner?.() || null;
        this.data.partner = partner
            ? { name: partner.name, mobile: partner.mobile, phone: partner.phone }
            : null;

        return super.dispatch(pos);
    },

    getOrderlineData(line) {
        const data = super.getOrderlineData(line);

        // we need barcode for your SRV-FEE skip logic
        data.barcode = line.product_id?.barcode || "";

        // mark selected line (for highlighting)
        const order = line.pos_order_id || line.order || null;
        const selected =
            order?.get_selected_orderline?.() ||
            order?.getSelectedOrderline?.() ||
            order?.get_selected_orderline?.() ||
            null;

        data.isSelected = !!(selected && selected.id === line.id);

        return data;
    },
});

/* ============================================================
 * C) DISPLAY SIDE: OWL UI behaviors (slider + feedback + create customer)
 * ============================================================ */
patch(CustomerDisplay.prototype, {
    setup() {
        super.setup(...arguments);

        this.state = useState({
            // slider state
            slideIndex: 0,

            // feedback popup state
            showFeedback: false,
            stars: 0,
            message: "",

            // create customer popup state
            showCreateCustomer: false,
            customer: {
                name: "",
                email: "",
                phone: "",
                street: "",
                city: "",
                state_id: "",
                country_id: "",
                zip: "",
            },
        });

        this._actionChannel = new BroadcastChannel(ACTION_CHANNEL);
        this._slideTimer = null;

        const clearTimer = () => {
            if (this._slideTimer) {
                clearTimeout(this._slideTimer);
                this._slideTimer = null;
            }
        };

        const tickSlider = () => {
            clearTimer();
            const imgs = this.order.sliderImages || [];
            if (!imgs.length) return;

            const sec = this.order.sliderTimerSec || 3;
            this._slideTimer = setTimeout(() => {
                this.state.slideIndex = (this.state.slideIndex + 1) % imgs.length;
                tickSlider();
            }, sec * 1000);
        };

        onMounted(() => tickSlider());
        onWillUnmount(() => clearTimer());

        // restart slider when data changes
        useEffect(
            () => {
                this.state.slideIndex = 0;
                tickSlider();
            },
            () => [this.order.sliderImages?.length, this.order.sliderTimerSec]
        );
    },

    /* ---------- Slider controls ---------- */
    nextSlide() {
        const imgs = this.order.sliderImages || [];
        if (!imgs.length) return;
        this.state.slideIndex = (this.state.slideIndex + 1) % imgs.length;
    },

    prevSlide() {
        const imgs = this.order.sliderImages || [];
        if (!imgs.length) return;
        this.state.slideIndex = (this.state.slideIndex - 1 + imgs.length) % imgs.length;
    },

    /* ---------- Feedback popup ---------- */
    openFeedback() {
        this.state.showFeedback = true;
        this.state.stars = 0;
        this.state.message = "";
    },

    cancelFeedback() {
        this.state.showFeedback = false;
    },

    setStars(n) {
        this.state.stars = n;
    },

    submitFeedback() {
        this._actionChannel.postMessage({
            type: "SUBMIT_FEEDBACK",
            payload: { rating: this.state.stars, message: this.state.message },
        });
        this.state.showFeedback = false;
    },

    /* ---------- Create customer popup ---------- */
    openCreateCustomer() {
        this.state.showCreateCustomer = true;
    },

    cancelCreateCustomer() {
        this.state.showCreateCustomer = false;
    },

    submitCreateCustomer() {
        if (!this.state.customer.name) return;

        this._actionChannel.postMessage({
            type: "CREATE_CUSTOMER",
            payload: { ...this.state.customer },
        });
        this.state.showCreateCustomer = false;
    },
});
