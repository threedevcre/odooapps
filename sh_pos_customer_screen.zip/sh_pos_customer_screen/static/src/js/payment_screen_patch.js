/** @odoo-module */
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { useService } from "@web/core/utils/hooks";
import { patch } from "@web/core/utils/patch";

patch(PaymentScreen.prototype, {
    setup() {
        super.setup();
        this.popup = useService("popup");
        this.pos = useService("pos");  // ✅ Correctly use POS service in Odoo 17
    },

    back() {

        // ✅ Correct way to get the order in Odoo 17
        const order = this.pos.get_order();
        if (order) {
            while (order.paymentlines.length > 0) {
                order.remove_paymentline(order.paymentlines[0]); // Remove payments one by one
            }
        }

        // ✅ Call the original `back()` method properly
        super.back();
    }
});
