/** @odoo-module */

import { Order, Orderline, Payment} from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(Orderline.prototype, {
    getDisplayData() {
        return {
            ...super.getDisplayData(),
            tax_details: this.get_applicable_taxes(),
            tax: this.get_tax(),
        };
    },
    get_tax_percentages() {
        return this.get_all_prices() ;
    }
}); 

patch(Order.prototype, {
    export_as_JSON() {
        var data = super.export_as_JSON(...arguments);
        data.invoice_number = this.invoice_number;
        data.post_data_fbr = this.post_data_fbr;
        data.fbr_request = this.fbr_request;
        data.fbr_respone = this.fbr_respone;
        data['total_discount']= this.get_total_discount()
        if (this.pos.config.sh_enable_fbr_connector_feature && this.pos.config.sh_enable_include_service) {
            data.sh_include_service_fee = true
            data.sh_service_fee = this.pos.config.sh_service_fee;
        }else{
            data.sh_include_service_fee = false
        }
         
        return data;
    },
    export_for_printing() {
        var receipt = super.export_for_printing(...arguments);
        if(this.pos.config.sh_enable_fbr_connector_feature && receipt && receipt.company){
            receipt.company['strn_or_ntn'] = this.pos.company.strn_or_ntn
        }
        return receipt
    },
    init_from_JSON(json) {
        this.invoice_number = json.invoice_number || false;
        this.post_data_fbr = json.post_data_fbr || false;
        this.fbr_respone = json.fbr_respone || false;
        this.fbr_request = json.fbr_request || false;

        super.init_from_JSON(json);
    },
    get_invoice_number() {
        return this.invoice_number;
    },
    set_invoice_number(invoice_number) {
        this.invoice_number = invoice_number;
    },
    get_post_data_fbr() {
        return this.post_data_fbr;
    },
    set_post_data_fbr(post_data_fbr) {
        this.post_data_fbr = post_data_fbr;
    },
    get_fbr_respone() {
        return this.fbr_respone;
    },
    set_fbr_respone(fbr_respone) {
        this.fbr_respone = fbr_respone;
    },
    get_fbr_request() {
        return this.fbr_request;
    },
    set_fbr_request(fbr_request) {
        this.fbr_request = fbr_request;
    },
});

patch(Payment.prototype, {
    export_for_printing() {
        var receipt = super.export_for_printing(...arguments);
        if(this.pos.config.sh_enable_fbr_connector_feature && receipt && this.payment_method && this.payment_method.payment_mode){
            receipt['payment_mode'] = this.payment_method.payment_mode
        }
        return receipt
    },
});
