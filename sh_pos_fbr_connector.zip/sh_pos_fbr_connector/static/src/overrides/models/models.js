/** @odoo-module */



import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { PosOrderline } from "@point_of_sale/app/models/pos_order_line";
import { PosPayment } from "@point_of_sale/app/models/pos_payment";



import { patch } from "@web/core/utils/patch";

patch(PosOrderline.prototype, {
    getDisplayData() {
        return {
            ...super.getDisplayData(),
            tax_details: this.get_applicable_taxes(),
            tax: this.get_tax(),
        };
    },
    get_tax_percentages() {
        return this.get_all_prices() ;
    }
});

patch(PosOrder.prototype, {
    export_as_JSON() {
        var data = super.export_as_JSON(...arguments);
        data.invoice_number = this.invoice_number;
        data.post_data_fbr = this.post_data_fbr;
        data.fbr_request = this.fbr_request;
        data.fbr_respone = this.fbr_respone;
        data['total_discount']= this.get_total_discount()
        if (this.pos.config.sh_enable_fbr_connector_feature && this.pos.config.sh_enable_include_service) {
            data.sh_include_service_fee = true
            data.sh_service_fee = this.pos.config.sh_service_fee;
        }else{
            data.sh_include_service_fee = false
        }

        return data;
    },

//    export_for_printing() {
//        var receipt = super.export_for_printing(...arguments);
//        var orderlines = receipt.orderlines;
//        if (orderlines.length > 0)
//        {
//            $.each(orderlines, function( i, line ){
//                var qty = parseFloat(line.qty, 10);
//                // Convert unitPrice from currency string to float
//                var unitPriceString = line.unitPrice;
//                var unitPrice = parseFloat(unitPriceString.replace(/[^0-9.-]/g, ''));
//                var PriceString = line.price;
//                var price = parseFloat(PriceString.replace(/[^0-9.-]/g, ''));
//                line['qty'] = qty
//                line['unitPrice'] = unitPrice
//                line['price'] = Math.round(price);
//                line['tax'] = Math.round(line.tax);
//            });
//        }
//        console.log('ssr', receipt);
//        if(this.pos.config.sh_enable_fbr_connector_feature && receipt && receipt.company){
//            receipt.company['strn_or_ntn'] = this.pos.company.strn_or_ntn
//        }
//        return receipt
//    },

//    export_for_printing() {
//        var receipt = super.export_for_printing(...arguments);
//        var orderlines = receipt.orderlines;
//        if (orderlines.length > 0)
//         {
//            $.each(orderlines, function(i, line) {
//                // Work with numbers
//                var qty = parseFloat(line.qty, 10);
//                var unitPrice = parseFloat(String(line.unitPrice).replace(/[^0-9.-]/g, ''));
//                var price = parseFloat(String(line.price).replace(/[^0-9.-]/g, ''));
//                var tax = parseFloat(line.tax);
//
//                // Store numeric values back (for UI safety)
//                line['qty'] = qty;
//                line['unitPrice'] = unitPrice;
//                line['price'] = Math.round(price);
//                line['tax'] = Math.round(tax);
//
//                // Add string fields only for printing
//                line['qty_str'] = qty.toString();
//                line['unitPrice_str'] = unitPrice.toFixed(2);
//                line['price_str'] = Math.round(price).toString();
//                line['tax_str'] = Math.round(tax).toString();
//            });
//        }
//
//        console.log('ssr', receipt);
//
//        if (this.pos.config.sh_enable_fbr_connector_feature && receipt && receipt.company) {
//            receipt.company['strn_or_ntn'] = this.pos.company.strn_or_ntn;
//        }
//
//        return receipt;
//    },




    init_from_JSON(json) {
        this.invoice_number = json.invoice_number || false;
        this.post_data_fbr = json.post_data_fbr || false;
        this.fbr_respone = json.fbr_respone || false;
        this.fbr_request = json.fbr_request || false;

        super.init_from_JSON(json);
    },
    get_invoice_number() {
        return this.invoice_number;
    },
    get_tracking_number_order() {
        return this.trackingNumber;
    },
    set_invoice_number(invoice_number) {
        this.invoice_number = invoice_number;
    },
    get_post_data_fbr() {
        return this.post_data_fbr;
    },
    set_post_data_fbr(post_data_fbr) {
        this.post_data_fbr = post_data_fbr;
    },
    get_fbr_respone() {
        return this.fbr_respone;
    },
    set_fbr_respone(fbr_respone) {
        this.fbr_respone = fbr_respone;
    },
    get_fbr_request() {
        return this.fbr_request;
    },
    set_fbr_request(fbr_request) {
        this.fbr_request = fbr_request;
    },
});


