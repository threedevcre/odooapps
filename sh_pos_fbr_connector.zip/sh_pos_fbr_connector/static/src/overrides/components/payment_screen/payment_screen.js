/** @odoo-module */

import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import OrderPaymentValidation from "@point_of_sale/app/utils/order_payment_validation";
import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";

import { FbrOrderReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/FbrOrderReceipt";
import { OrderReceipt } from "@point_of_sale/app/screens/receipt_screen/receipt/order_receipt";
import { custom_fbr_receipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/custom_fbr_receipt";

import { ask } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { _t } from "@web/core/l10n/translation";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { useTrackedAsync } from "@point_of_sale/app/hooks/hooks";

// ============================================================================
//  HELPERS: build old-style UI JSON for FBR (equivalent to export_as_JSON)
// ============================================================================

function buildFbrUiOrder(pos, order) {
    const taxTotals = order.taxTotals || {};
    let totalTax = 0;
    if (taxTotals.subtotals) {
        for (const subtotal of taxTotals.subtotals) {
            for (const group of subtotal.tax_groups || []) {
                totalTax += group.tax_amount_currency || 0;
            }
        }
    }

    const amount_total = order.getTotalWithTax
        ? order.getTotalWithTax()
        : taxTotals.order_sign
        ? taxTotals.order_sign * taxTotals.order_total
        : 0;

    const total_discount = order.getTotalDiscount ? order.getTotalDiscount() : 0;

    const partner = order.getPartner ? order.getPartner() : order.partner || null;

    // Build a safe "name" to use as USIN on the Python side.
    // In OWL POS, order.name is often "/" until the order is pushed.
    const rawName = order.name || "";
    const safeName =
        rawName && rawName !== "/"
            ? rawName
            : order.uid || rawName; // fall back to UID so we never send "/"

    // Make sure old_pos_reference is at least an empty string, not null/undefined
    const oldPosReference = order.old_pos_reference || "";

    // --- payment lines -> statement_ids in old export_as_JSON style
    const paymentLines = (order.payment_ids || []).filter((p) => !p.is_change);
    const statement_ids = paymentLines.map((line) => [
        0,
        0,
        {
            amount: line.getAmount ? line.getAmount() : line.amount,
            payment_method_id: line.payment_method_id?.id,
        },
    ]);

    // --- order lines -> lines: [[0, 0, {...}], ...] like old POS
    const rawLines = order.getOrderlines ? order.getOrderlines() : order.lines || [];
    let tmpId = 1;
    const lines = rawLines.map((line) => {
        const qty = line.getQuantity ? line.getQuantity() : line.qty;
        const allPrices = line.getAllPrices ? line.getAllPrices() : line.allPrices || {};
        const priceWithTax = allPrices.priceWithTax ?? allPrices.price_with_tax ?? 0;
        const taxAmount = allPrices.tax ?? allPrices.taxAmount ?? 0;
        const priceWithoutTax =
            allPrices.priceWithoutTax ??
            allPrices.price_without_tax ??
            priceWithTax - taxAmount;

        const discount = line.getDiscount ? line.getDiscount() : line.discount || 0;

        // tax_ids m2m in old JSON: [[6, 0, [tax_ids...]]]
        const tax_ids_raw =
            line.tax_ids?.map((t) => t.id) ||
            line.allTaxes?.map((t) => t.id) ||
            [];
        const tax_ids = tax_ids_raw.length ? [[6, 0, tax_ids_raw]] : [];

        const combo_parent_id = line.combo_parent_id?.id || null;
        const id = line.id || tmpId++;

        return [
            0,
            0,
            {
                id,
                product_id: line.product_id?.id,
                default_code: line.product_id?.default_code || "",
                qty,
                price_unit:
                    (line.getUnitDisplayPrice && line.getUnitDisplayPrice()) ??
                    line.price_unit ??
                    0,
                price_subtotal: priceWithoutTax,
                price_subtotal_incl: priceWithTax,
                discount,
                tax_ids,
                combo_parent_id,
            },
        ];
    });

    // This JSON matches what your old Python code was using, but with safe name/ref.
    return {
        uuid: order.pos_reference, // helps build unique_id if needed
        name: safeName,
        amount_total,
        amount_tax: totalTax,
        total_discount,
        old_pos_reference: order.old_pos_reference,
        pos_session_id: pos.session.id,
        partner_id: partner ? partner.id : false,
        statement_ids,
        lines,
    };
}

// ============================================================================
//  VALIDATION OVERRIDE (FBR)
// ============================================================================

const originalValidateOrder = OrderPaymentValidation.prototype.validateOrder;

patch(OrderPaymentValidation.prototype, {
    async validateOrder(isForceValidate) {
        const order = this.order;

        if (!(await this.isOrderValid(isForceValidate))) {
            return;
        }

        // === FBR online call (unchanged from your code) ===
        if (this.pos.config.sh_enable_fbr_connector_feature && order) {
            try {
                const uiOrder = buildFbrUiOrder(this.pos, order);

                const data = await this.pos.data.call(
                    "pos.order",
                    "post_data_fbi",
                    [uiOrder]
                );

                if (data && data[0] === 1 && data[1]) {
                    order.set_invoice_number?.(data[1]);
                    order.set_post_data_fbr?.(true);
                    order.set_fbr_request?.(data[2]);
                    order.set_fbr_respone?.(data[3]);
                } else if (data && data[0] === 2) {
                    order.set_fbr_request?.(data[1]);
                    order.set_fbr_respone?.(data[2]);
                }
            } catch (e) {
                console.error("FBR online call failed:", e);
                order.set_post_data_fbr?.(false);
            }
        }

        // Run the original validation (finalizeValidation + navigation)
        return await originalValidateOrder.call(this, isForceValidate);
    },

    // === NEW: override afterOrderValidation to control auto-print ===
    async afterOrderValidation(validated) {
        // Keep original behavior: send to kitchen / preparation
        if (!this.pos.config.module_pos_restaurant) {
            this.pos.checkPreparationStateAndSentOrderInPreparation(this.order, {
                orderDone: true,
            });
        }

        const order = this.order;

        // Our custom auto-print logic
        if (order.nb_print === 0 && this.pos.config.iface_print_auto) {
            const invoiced_finalized = order.isToInvoice() ? order.finalized : true;
            if (invoiced_finalized) {
                const printer = this.pos.env.services.printer;
                const formatCurrency = this.pos.env.utils.formatCurrency;

                const ComponentToPrint = this.pos.config.sh_enable_fbr_connector_feature
                    ? FbrOrderReceipt
                    : custom_fbr_receipt;

                await printer.print(
                    ComponentToPrint,
                    { order, formatCurrency },
                    { webPrintFallback: true }
                );
            }
        }

        // You can return something if you want,
        // but core doesn't use the return value for navigation logic anymore.
        return true;
    },
});

// ============================================================================
//  AFTER ORDER VALIDATION (auto-print with FbrOrderReceipt)
// ============================================================================

patch(PaymentScreen.prototype, {
    async afterOrderValidation(suggestToSync = true) {
        this.pos.db.remove_unpaid_order(this.currentOrder);

        if (suggestToSync && this.pos.db.get_orders().length) {
            const confirmed = await ask(this.dialog, {
                title: _t("Remaining unsynced orders"),
                body: _t(
                    "There are unsynced orders. Do you want to sync these orders?"
                ),
            });

            if (confirmed) {
                this.pos.push_orders();
            }
        }

        let nextScreen = this.nextScreen;
        const order = this.currentOrder;

        if (
            nextScreen === "ReceiptScreen" &&
            !order._printed &&
            this.pos.config.iface_print_auto
        ) {
            const invoiced_finalized = order.is_to_invoice()
                ? order.finalized
                : true;

            if (invoiced_finalized) {
                let printResult;
                if (this.pos.config.sh_enable_fbr_connector_feature) {
                    printResult = await this.printer.print(
                        FbrOrderReceipt,
                        {
                            order,
                            formatCurrency: this.env.utils.formatCurrency,
                        },
                        { webPrintFallback: true }
                    );
                } else {
                    printResult = await this.printer.print(
                        custom_fbr_receipt,
                        {
                            order,
                            formatCurrency: this.env.utils.formatCurrency,
                        },
                        { webPrintFallback: true }
                    );
                }

                if (printResult && this.pos.config.iface_print_skip_screen) {
                    this.pos.removeOrder(order);
                    this.pos.add_new_order();
                    nextScreen = "ProductScreen";
                }
            }
        }

        this.pos.showScreen(nextScreen);
    },
});

// ============================================================================
//  RECEIPT SCREEN PATCH (manual Print → use FbrOrderReceipt)
// ============================================================================

const originalReceiptScreenSetup = ReceiptScreen.prototype.setup;

patch(ReceiptScreen.prototype, {
    setup() {
        // Call original setup to keep all default behavior
        originalReceiptScreenSetup.call(this);

        // Add printer service (default ReceiptScreen did not need it)
        this.printer = useService("printer");

        // Override full & basic print actions to use our own logic
        this.doFullPrint = useTrackedAsync(() => this._fbrDoPrint(false));
        this.doBasicPrint = useTrackedAsync(() => this._fbrDoPrint(true));
    },

    /**
     * Internal print function used by both "Print" and "Print Basic" buttons
     * on the Receipt screen. Chooses FbrOrderReceipt when FBR is enabled.
     */
    async _fbrDoPrint(basicReceipt = false) {
        const order = this.currentOrder;

        // Decide which component to print
        const ComponentToPrint = this.pos.config.sh_enable_fbr_connector_feature
            ? FbrOrderReceipt
            : custom_fbr_receipt;

        await this.printer.print(
            ComponentToPrint,
            {
                order,
                basic_receipt: basicReceipt,
                // FbrOrderReceipt expects formatCurrency; OrderReceipt will ignore
                formatCurrency: this.env.utils.formatCurrency,
            },
            { webPrintFallback: true }
        );
    },
});
