/** @odoo-module */
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { patch } from "@web/core/utils/patch";
import { FbrOrderReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/FbrOrderReceipt";
import { CustomReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/CustomReceipt";
import { OrderReceipt } from "@point_of_sale/app/screens/receipt_screen/receipt/order_receipt";

patch(PaymentScreen.prototype, {
    async validateOrder(isForceValidate) {
        var self = this;

        $(".next").prop("disabled", true);
        $(".next").css("pointer-events", "None");
        $(".next").css("cursor", "None");

        var pos_order = this.currentOrder;
        
        if (await this._isOrderValid(isForceValidate)) {
            if (self.pos.config.sh_enable_fbr_connector_feature) {
                try {

                    const data = await self.pos.orm.call("pos.order", "post_data_fbi", [
                        [pos_order.uid], [pos_order.export_as_JSON()]
                    ]);
                    if (data && data[0] && data[0] == 1 && data[1]) {
                        pos_order.set_invoice_number(data[1]);
                        pos_order.set_post_data_fbr(true)
                        pos_order.set_fbr_request(data[2])
                        pos_order.set_fbr_respone(data[3])
                    } else if (data && data[0] && data[0] == 2) {
                        pos_order.set_fbr_request(data[1])
                        pos_order.set_fbr_respone(data[2])
                    }
                    } catch (e) {
                        pos_order.set_post_data_fbr(false)
                   }

                await super.validateOrder(...arguments);
            } else {
                await super.validateOrder(...arguments);
            }
        } else {
            await super.validateOrder(...arguments);
        }
    },
    async afterOrderValidation(suggestToSync = true) {
        // Remove the order from the local storage so that when we refresh the page, the order
        // won't be there
        this.pos.db.remove_unpaid_order(this.currentOrder);

        // Ask the user to sync the remaining unsynced orders.
        if (suggestToSync && this.pos.db.get_orders().length) {
            const { confirmed } = await this.popup.add(ConfirmPopup, {
                title: _t("Remaining unsynced orders"),
                body: _t("There are unsynced orders. Do you want to sync these orders?"),
            });
            if (confirmed) {
                // NOTE: Not yet sure if this should be awaited or not.
                // If awaited, some operations like changing screen
                // might not work.
                this.pos.push_orders();
            }
        }
        // Always show the next screen regardless of error since pos has to
        // continue working even offline.
        let nextScreen = this.nextScreen;

        if (
            nextScreen === "ReceiptScreen" &&
            !this.currentOrder._printed &&
            this.pos.config.iface_print_auto
        ) {
            const invoiced_finalized = this.currentOrder.is_to_invoice()
                ? this.currentOrder.finalized
                : true;

            if (invoiced_finalized) {
                if(this.pos.config.sh_enable_fbr_connector_feature){
                    const printResult = await this.printer.print(
                        FbrOrderReceipt,
                        {
                            order: this.pos.get_order(),
                            formatCurrency: this.env.utils.formatCurrency,
                        },
                        { webPrintFallback: true }
                    );
    
                    if (printResult && this.pos.config.iface_print_skip_screen) {
                        this.pos.removeOrder(this.currentOrder);
                        this.pos.add_new_order();
                        nextScreen = "ProductScreen";
                    }
                }else{
                    const printResult = await this.printer.print(
                        CustomReceipt,
                        {
                            order: this.pos.get_order(),
                            formatCurrency: this.env.utils.formatCurrency,
                        },
                        { webPrintFallback: true }
                    );
    
                    if (printResult && this.pos.config.iface_print_skip_screen) {
                        this.pos.removeOrder(this.currentOrder);
                        this.pos.add_new_order();
                        nextScreen = "ProductScreen";
                    }
                }
            }
        }

        this.pos.showScreen(nextScreen);
    }
});
