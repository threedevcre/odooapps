/** @odoo-module */

import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";
import { FbrOrderReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/FbrOrderReceipt";
import { patch } from "@web/core/utils/patch";
import { custom_fbr_receipt as CustomFbrReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/custom_fbr_receipt";

/**
 * Odoo 19 ReceiptScreen no longer has printReceipt() and does not use
 * export_for_printing(). It renders <OrderReceipt order="currentOrder" ...>
 * directly and uses this.pos.printReceipt() internally.
 *
 * We DON'T touch printing here (your PaymentScreen patch already prints
 * FbrOrderReceipt when FBR is enabled). We only:
 *   - register FbrOrderReceipt as a component
 *   - let the XML decide whether to show FBR or default receipt
 */

patch(ReceiptScreen, {
    components: {
        ...ReceiptScreen.components,
        FbrOrderReceipt,
        CustomFbrReceipt,
    },
});
