/** @odoo-module */

import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";
import { FbrOrderReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/FbrOrderReceipt";
import { CustomReceipt } from "@sh_pos_fbr_connector/app/FbrOrderReceipt/CustomReceipt";
import { patch } from "@web/core/utils/patch";
import { ReprintReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/reprint_receipt_screen";
import { OrderReceipt } from "@point_of_sale/app/screens/receipt_screen/receipt/order_receipt";

patch(ReceiptScreen.prototype, {

    async printReceipt() {
        if(this.pos.config.sh_enable_fbr_connector_feature){
            this.buttonPrintReceipt.el.className = "fa fa-fw fa-spin fa-circle-o-notch";
            const isPrinted = await this.printer.print(
                FbrOrderReceipt,
                {
                    order: this.pos.get_order(),
                    formatCurrency: this.env.utils.formatCurrency,
                },
                { webPrintFallback: true }
            );
    
            if (isPrinted) {
                this.currentOrder._printed = true;
            }
    
            if (this.buttonPrintReceipt.el) {
                this.buttonPrintReceipt.el.className = "fa fa-print";
            }
        }else{
            this.buttonPrintReceipt.el.className = "fa fa-fw fa-spin fa-circle-o-notch";
            const isPrinted = await this.printer.print(
                CustomReceipt,
                {
                    order: this.pos.get_order(),
                    formatCurrency: this.env.utils.formatCurrency,
                },
                { webPrintFallback: true }
            );

            if (isPrinted) {
                this.currentOrder._printed = true;
            }

            if (this.buttonPrintReceipt.el) {
                this.buttonPrintReceipt.el.className = "fa fa-print";
            }
        }
    }
});

patch(ReceiptScreen, {
    components: { ...ReceiptScreen.components, FbrOrderReceipt,CustomReceipt },
});
patch(ReprintReceiptScreen, {
    components: { ...ReprintReceiptScreen.components, FbrOrderReceipt, CustomReceipt },
});
https://dowstudio-staging-23655099.dev.odoo.com/web/image/res.users/14/avatar_128?unique=1765361209366
patch(ReprintReceiptScreen.prototype, {

    tryReprint() {
        if(this.pos.config.sh_enable_fbr_connector_feature){
            this.printer.print(
                FbrOrderReceipt,
                {
                    order: this.props.order,
                    formatCurrency: this.env.utils.formatCurrency,
                },
                { webPrintFallback: true }
            );
        }else{
            this.printer.print(
                CustomReceipt,
                {
                    order: this.props.order,
                    formatCurrency: this.env.utils.formatCurrency,
                },
                { webPrintFallback: true }
            );
        }
    }
});