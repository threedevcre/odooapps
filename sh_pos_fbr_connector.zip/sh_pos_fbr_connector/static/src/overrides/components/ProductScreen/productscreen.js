/** @odoo-module */

console.log("✅ pos_auto_service_fee.js LOADED");

import { PosStore } from "@point_of_sale/app/services/pos_store";
import { patch } from "@web/core/utils/patch";

const SERVICE_FEE_CODE = "SRV-FEE";
const SERVICE_FEE_NAME_PART = "service";

patch(PosStore.prototype, {
    async pay() {
        // ✅ add service fee right before going to payment screen
        await this._ensureServiceFeeBeforePayment();

        // continue normal flow
        return await super.pay();
    },

    async _ensureServiceFeeBeforePayment() {
        if (!this.config?.sh_enable_fbr_connector_feature || !this.config?.sh_enable_include_service) {
            return;
        }

        const order = this.getOrder();
        if (!order) return;

        // Optional: don’t add fee if order empty
        if (!order.getOrderlines()?.length) return;

        // Find Service Fee product from already-loaded POS products
        const products = this.models["product.product"].getAll();
        const serviceProduct =
            products.find((p) => (p.default_code || "").toUpperCase() === SERVICE_FEE_CODE) ||
            products.find((p) =>
                (p.display_name || p.name || "").toLowerCase().includes(SERVICE_FEE_NAME_PART)
            );

        if (!serviceProduct) {
            console.warn("❌ Service Fee product not found in loaded POS products");
            return;
        }

        // Prevent duplicate
        const alreadyAdded = order
            .getOrderlines()
            .some((l) => l.product_id?.id === serviceProduct.id);

        if (alreadyAdded) return;

        // Set amount from POS config field
        const fee = Number(this.config.sh_service_fee || 0);
        if (fee <= 0) return;

        // ✅ Add line with forced price
        await this.addLineToCurrentOrder(
            {
                product_id: serviceProduct,
                product_tmpl_id: serviceProduct.product_tmpl_id,
                qty: 1,
                price_unit: fee,
            },
            { merge: false },
            true
        );

        console.log("✅ Service Fee added before Payment:", fee);
    },
});
