/** @odoo-module **/

import { Order } from "@point_of_sale/app/store/models";
import { _t } from "@web/core/l10n/translation";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { patch } from "@web/core/utils/patch";

patch(Order.prototype, {
    async pay() {
        const order = this.pos.get_order();
        let allowPay = true;
        let totalAmount = 0;

        /* ================================
           SERVICE FEE (Odoo 17 way)
        ================================= */
        if (this.pos.config.sh_enable_fbr_connector_feature && this.pos.config.sh_enable_include_service) {
            const serviceProduct = Object.values(this.pos.db.product_by_id)
                .find(p => p.default_code === "SRV-FEE");

            if (!serviceProduct) {
                this.env.services.popup.add(ErrorPopup, {
                    title: _t("Configuration Error"),
                    body: _t("Service Fee product (SRV-FEE) is not loaded in POS."),
                });
                return false;
            }

            // Remove old service fee
            order.get_orderlines()
                .filter(line => line.get_product() === serviceProduct)
                .forEach(line => order._unlinkOrderline(line));

            // Calculate total (excluding service fee)
            order.get_orderlines().forEach(line => {
                totalAmount += line.get_price_with_tax();
            });

            // Add service fee line
            order.add_product(serviceProduct, {
                price: this.pos.config.sh_service_fee,
                quantity: 1,
                merge: false,
            });
        }
        return super.pay(...arguments);
}
});
