/** @odoo-module */

import { Component } from "@odoo/owl";
import { Orderline } from "@point_of_sale/app/generic_components/orderline/orderline";
import { OrderWidget } from "@point_of_sale/app/generic_components/order_widget/order_widget";
import { ReceiptHeader } from "@point_of_sale/app/screens/receipt_screen/receipt/receipt_header/receipt_header";
import { omit } from "@web/core/utils/objects";

export class CustomReceipt extends Component {
    static template = "sh_pos_fbr_connector.CustomReceipt";

    static components = {
        Orderline,
        ReceiptHeader,
        OrderWidget,
    };

    static props = {
        order: { type: Object, optional: true },
        data: { type: Object, optional: true },
        formatCurrency: Function,
    };

    omit(...args) {
        return omit(...args);
    }

    get receipt() {
        const order =
            this.props.order ||
            this.env.services.pos?.get_order();

        if (!order) {
            console.warn("⚠️ No order available for printing yet");
            return {};
        }

        const receipt = order.export_for_printing();
        console.log("✅ Receipt Data:", receipt);

        if (receipt.loyaltyStats) {
            console.log("🎯 Loyalty Points:", receipt.loyaltyStats);
        } else {
            console.log("ℹ️ No loyalty points data");
        }

        return receipt;
    }
}
