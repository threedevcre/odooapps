/** @odoo-module */

import { Component } from "@odoo/owl";
import { Orderline } from "@point_of_sale/app/components/orderline/orderline";
import { ReceiptHeader } from "@point_of_sale/app/screens/receipt_screen/receipt/receipt_header/receipt_header";
import { OrderDisplay } from "@point_of_sale/app/components/order_display/order_display";
import { _t } from "@web/core/l10n/translation";
import { formatCurrency } from "@web/core/currency";
import { generateQRCodeDataUrl } from "@point_of_sale/utils";

export class FbrOrderReceipt extends Component {
    static template = "sh_pos_fbr_connector.FbrOrderReceipt";
    static components = { Orderline, OrderDisplay, ReceiptHeader };

    static props = {
        order: Object,
        basic_receipt: { type: Boolean, optional: true },
        formatCurrency: { type: Function, optional: true },
    };

    static defaultProps = {
        basic_receipt: false,
    };

    get order() {
        return this.props.order;
    }

    get header() {
        return {
            company: this.order.company,
            cashier: _t("Served by %s", this.order?.getCashierName?.() || ""),
            header: this.order.config?.receipt_header,
        };
    }

    formatCurrency(amount) {
        if (this.props.formatCurrency) {
            return this.props.formatCurrency(amount);
        }
        return formatCurrency(amount || 0, this.order.currency.id);
    }

    get qrCode() {
        const baseUrl = this.order.config?._base_url || "";
        if (!baseUrl || !this.order.access_token) return null;
        const url = `${baseUrl}/pos/ticket/validate?access_token=${this.order.access_token}`;
        return generateQRCodeDataUrl(url);
    }

    get paymentLines() {
        return (this.order.payment_ids || []).filter((p) => !p.is_change);
    }

    get receipt() {
        const order = this.order;
        const paymentLines = this.paymentLines || [];

        const rawLines = order.getOrderlines ? order.getOrderlines() : order.lines || [];

        // ---- ORDERLINES (fields exactly as XML expects) ----
        const orderlines = rawLines.map((line, index) => {
            const qty = line.getQuantity ? line.getQuantity() : line.qty || 0;
            const unit_price = line.getUnitPrice ? line.getUnitPrice() : line.price_unit || 0;

            const priceWithTax = line.getPriceWithTax
                ? line.getPriceWithTax()
                : line.price_subtotal_incl || 0;

            const priceWithoutTax = line.getPriceWithoutTax
                ? line.getPriceWithoutTax()
                : line.price_subtotal || 0;

            const taxAmount = priceWithTax - priceWithoutTax;

            return {
                id: line.id || index,
                productName:
                    line.product_id?.display_name ||
                    line.product_id?.name ||
                    line.full_product_name ||
                    "",
                qty: qty,
                unit_price: unit_price,
                price: priceWithTax,          // XML uses line.price
                tax: taxAmount,               // XML uses line.tax
                discount: line.getDiscount ? line.getDiscount() : line.discount || 0,
                priceWithoutTax: priceWithoutTax,
                default_code: line.product_id?.default_code || "",
            };
        });

        // ---- TAX TOTAL ----
        let amount_tax = 0;
        const taxTotals = order.taxTotals;

        if (taxTotals && taxTotals.subtotals) {
            for (const subtotal of taxTotals.subtotals) {
                for (const group of subtotal.tax_groups || []) {
                    amount_tax += group.tax_amount_currency || 0;
                }
            }
        } else {
            amount_tax = order.amount_tax || 0;
        }

        // ---- TAX DETAILS (for your XML loops) ----
        let taxLabel = "GST";
        let taxPercent = 0;

        const firstLine = rawLines.find((l) => l.tax_ids && l.tax_ids.length);
        if (firstLine && firstLine.tax_ids[0]) {
            const tax = firstLine.tax_ids[0];
            taxPercent = tax.amount || 0;
            if (tax.name && tax.name.includes("%")) {
                taxLabel = tax.name;
            } else {
                taxLabel = `${tax.name || "GST"} ${taxPercent}%`;
            }
        }

        const tax_details =
            amount_tax > 0
                ? [
                      {
                          id: 1,
                          name: taxLabel,
                          amount: amount_tax,
                          percent: taxPercent,
                      },
                  ]
                : [];

        // ---- TOTALS ----
        const total_quantity = orderlines.reduce((sum, l) => sum + (l.qty || 0), 0);
        const total_without_tax = orderlines.reduce(
            (sum, l) => sum + (l.priceWithoutTax || 0),
            0
        );

        const amount_total = order.getTotalWithTax
            ? order.getTotalWithTax()
            : order.amount_total || 0;

        const total_paid = paymentLines.reduce((sum, p) => {
            const amt = p.getAmount ? p.getAmount() : p.amount || 0;
            return sum + amt;
        }, 0);

        const change = total_paid - amount_total;

        const total_discount = order.getTotalDiscount
            ? order.getTotalDiscount()
            : order.total_discount || 0;

        // ---- DATE ----
        const rawDate =
            order.date_order || order.validation_date || order.creation_date || "";
        const date = rawDate ? new Date(rawDate).toLocaleString() : "";

        // ---- FINAL OBJECT (matches your XML) ----
        return {
            headerData: this.header,
            uid: order.pos_reference,
            ntn: this.header.company?.vat,
            gst: this.header.company?.strn_or_ntn,
            state: order.preset_id ? order.preset_id.name : "",
            name: order.name,
            date,
            orderlines,
            total_quantity,
            total_without_tax,
            amount_tax,
            amount_total,
            total_discount,
            total_paid,
            change,
            paymentlines: paymentLines.map((line) => {
                const method = line.payment_method || line.payment_method_id;
                return {
                    name: method?.id || "",
                    payment_mode: method?.type || "",
                    amount: line.getAmount ? line.getAmount() : line.amount || 0,
                };
            }),
            pos_qr_code: this.qrCode,
            tax_details,
            note: order.note || "",
            footer: order.config?.receipt_footer || "",
            ticket_code: order.ticket_code,
            base_url: order.config?._base_url || "",
        };
    }
}
