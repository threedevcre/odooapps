/** @odoo-module */

import { Component } from "@odoo/owl";
import { Orderline } from "@point_of_sale/app/generic_components/orderline/orderline";
import { OrderWidget } from "@point_of_sale/app/generic_components/order_widget/order_widget";
import { ReceiptHeader } from "@point_of_sale/app/screens/receipt_screen/receipt/receipt_header/receipt_header";
import { omit } from "@web/core/utils/objects";

export class FbrOrderReceipt extends Component {
    static template = "sh_pos_fbr_connector.FbrOrderReceipt";
    static components = {
        Orderline,
        ReceiptHeader,
        OrderWidget
    };
    omit(...args) {
        return omit(...args);
    }
    static props = {
        order: Object,
        data: { type: Object, optional: true },
        formatCurrency: Function,
    };


//    get receipt() {
//        const data = this.props.data || {};
//
////        return this.props.order.export_for_printing();
//        return this.props.order ? this.props.order.export_for_printing() : null;
//    }



    get receipt() {
        const data = this.props.data || {};
        console.log("Receipt Data ------------------ ", this.props.order.export_for_printing());

        const receipt = this.props.order ? this.props.order.export_for_printing() : null;

        if (receipt && receipt.loyaltyStats) {
            console.log("Loyalty Points Data --------------- : ", receipt.loyaltyStats);
        } else {
            console.log("No loyalty points data available -------------------- ");
        }

        return receipt;
    }


}




