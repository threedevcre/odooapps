# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
from odoo import fields, models, api, _

class Product(models.Model):
    _inherit = 'product.template'

    pct_code = fields.Char("PCT Code", required=False)


class Product(models.Model):
    _inherit = 'product.product'

    is_service_fee = fields.Boolean("Service Fee?")
