# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
from odoo import fields, models, api, _
from odoo.exceptions import UserError

class PosSession(models.Model):
    _inherit = 'pos.session'

    sh_service_fee_journal = fields.Many2one(
        'account.move', string='Service Fee Journal')

    def _loader_params_pos_order(self):
        result = super()._loader_params_pos_order()
        result['search_params']['fields'].extend(['invoice_number','post_data_fbr', 'fbr_request', 'fbr_respone'])
        return result

    def _loader_params_pos_order_line(self):
        result = super()._loader_params_pos_order_line()
        result['search_params']['fields'].extend(['tax_ids_after_fiscal_position'])
        return result

    def _loader_params_res_company(self):
        result = super()._loader_params_res_company()
        result['search_params']['fields'].extend(['strn_or_ntn'])
        return result

    def _loader_params_res_partner(self):
        result = super()._loader_params_res_partner()
        result['search_params']['fields'].extend(['cnic','ntn'])
        return result

    def _loader_params_pos_payment_method(self):
        result = super()._loader_params_pos_payment_method()
        result['search_params']['fields'].extend(['payment_mode'])
        return result

    def _validate_session(self, balancing_account=False, amount_to_balance=0, bank_payment_method_diffs=None):
        res = super(PosSession, self)._validate_session(balancing_account, amount_to_balance, bank_payment_method_diffs)
        orders = self.env['pos.order'].search(
            [('session_id', '=', self.id), ('sh_include_service_fee', '=', True)])

        if orders:
            service_fee = 0.00
            for each_order in orders:
                if each_order.post_data_fbr and each_order.sh_service_fee:
                    service_fee = service_fee + each_order.sh_service_fee
            journal_id = self.env['account.journal'].search(
                [('type', '=', 'sale')], limit=1)
            ref = "FBR Service Fee " + self.name
            date_tz_user = fields.Datetime.context_timestamp(
                self, fields.Datetime.from_string(self.start_at))
            date_tz_user = fields.Date.to_string(date_tz_user)

            if service_fee > 0.0:
                move_id = self.env['account.move'].sudo().create(
                    {'ref': ref, 'journal_id': journal_id.id, 'date': date_tz_user})

                if move_id:

                    fbr_service_cost_account = self.env['account.account'].search(
                        [('code', '=', '444444'), ('company_id', '=', self.env.company.id)], limit=1)
                    if not fbr_service_cost_account:
                        
                        fbr_service_cost_account =  self.env['account.account'].create({'name': 'FBR Service Cost', 'code': '444444', 'account_type': 'expense', 'company_id':self.env.company.id })
                        
                    fbr_service_cost_account_id = fbr_service_cost_account.id

                    service_product = self.env.ref(
                        'sh_pos_fbr_connector.sh_demo_product_for_service_fees')
                    accounts = service_product.product_tmpl_id.get_product_accounts(
                        0)
                    if accounts == False:
                        raise UserError(
                            _("No account defined for this product: "))
                    all_lines = []
                    if fbr_service_cost_account_id:
                        vals = {

                            'credit': service_fee,
                            'debit': 0,
                            'account_id': fbr_service_cost_account_id,
                            'move_id': move_id.id,
                            'partner_id': False,
                            'name': "FBR Service Cost",
                        }
                        all_lines.append((0, 0, vals))
                    if accounts and accounts['income'] and accounts['income'].id:
                        vals = {

                            'debit': service_fee,
                            'credit': 0,
                            'account_id': accounts['income'].id,
                            'move_id': move_id.id,
                            'partner_id': False,
                            'name': "Service Fees",
                        }
                        all_lines.append((0, 0, vals))
                    if all_lines:
                        move_id.sudo().write({'line_ids': all_lines})
                        move_id.sudo().action_post()

                    self.write({'sh_service_fee_journal': move_id.id})
        return res
