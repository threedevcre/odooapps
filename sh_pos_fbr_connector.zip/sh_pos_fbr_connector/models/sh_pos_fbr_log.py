# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
from odoo import fields, models, api, _


class FBRLog(models.Model):
    _name = 'sh.fbr.log'
    _order = 'id desc'
    _description = "FBR Log"

    name = fields.Char("POS Order Ref")
    fbr_request = fields.Text("FBR Request")
    fbr_response = fields.Text("FBR Response")
    fbr_invoice_number = fields.Char("FBR Invoice Number")
    posted_succesfull = fields.Boolean("Posted Successfully ?")
