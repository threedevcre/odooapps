# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import fields, models, api


class PaymentMethod(models.Model):
    _inherit = 'pos.payment.method'

    payment_mode = fields.Selection([
        ('1', 'Cash'),
        ('2', 'Card'),
        ('3', 'Gift Voucher'),
        ('4', 'Loyalty Card'),
        ('5', 'Mixed'),
        ('6', 'Cheque'),
    ], required=True, default='1',export_to_pos=True,)

    @api.model
    def _load_pos_data_fields(self, config_id):
        """Odoo 18/19 style: add extra fields to the POS payload."""
        fields_list = super()._load_pos_data_fields(config_id)
        if 'payment_mode' not in fields_list:
            fields_list.append('payment_mode')
        return fields_list

