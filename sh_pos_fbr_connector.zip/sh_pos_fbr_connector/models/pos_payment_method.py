# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import fields, models, api, _

class PaymentMethod(models.Model):
    _inherit = 'pos.payment.method'

    payment_mode = fields.Selection([
        ('1', 'Cash'),
        ('2', 'Card'),
        ('3', 'Gift Voucher'),
        ('4', 'Loyalty Card'),
        ('5', 'Mixed'),
        ('6', 'Cheque'),
    ], required=True, default='1')

    not_push_to_fbr = fields.Boolean('Push to Portal Blocked')

