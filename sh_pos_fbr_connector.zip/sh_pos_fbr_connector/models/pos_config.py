# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
from odoo import fields, models, api, _


class PosConfig(models.Model):
    _inherit = 'pos.config'

    sh_enable_fbr_connector_feature = fields.Boolean(
        string="Enable FBR Connector")
    sh_fbr_authentication_type = fields.Selection([('sand_box', 'Sandbox'), (
        'production', 'Production')], string="FBR Authentication", default="sand_box")
    pos_id = fields.Char("POSID", required=False)
    fbr_authorization = fields.Char("FBR Header Authorization", required=False)
    sh_receipt_logo = fields.Binary("Receipt Logo", required="0")
    sh_enable_include_service = fields.Boolean(string="Include Service Fee")
    sh_service_fee = fields.Float(string="Service Fee", default="1")

    def get_pos_product_id(self, order_id=None):
        return self.env.ref('sh_pos_fbr_connector.sh_demo_product_for_service_fees')[0].id if len(self.env.ref('sh_pos_fbr_connector.sh_demo_product_for_service_fees')) > 0 else 0
