# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from collections import defaultdict
from datetime import timedelta
import json
import logging
import traceback
import requests

from odoo import api, fields, models, _

import requests

try:
    import qrcode
except ImportError:
    qrcode = None
try:
    import base64
except ImportError:
    base64 = None

from io import BytesIO

_logger = logging.getLogger(__name__)


class POSOrder(models.Model):
    _inherit = 'pos.order'

    # =====================================================================
    # FIELDS
    # =====================================================================
    fbr_request = fields.Text("FBR Request")
    fbr_respone = fields.Text("FBR Response")
    post_data_fbr = fields.Boolean("Post Data Successful ?")
    pos_reference = fields.Char(string='Receipt Ref', readonly=True, copy=True)
    invoice_number = fields.Char("Invoice Number")
    sh_include_service_fee = fields.Boolean(string="Include Service Fee")
    sh_service_fee = fields.Float(string="Service Fee")
    total_discount = fields.Float(string="Total Discount")

    pos_receipt_header = fields.Text(
        string='Receipt Header', readonly=False, store=True
    )
    pos_receipt_footer = fields.Text(
        string='Receipt Footer', readonly=False, store=True
    )

    qr_code = fields.Binary(
        'QRcode',
        compute="_generate_qr",
        store=True,
    )

    old_pos_reference = fields.Char(string='Old POS Reference')

    # =====================================================================
    # QR CODE COMPUTE
    # =====================================================================
    @api.depends('invoice_number')
    def _generate_qr(self):
        for rec in self:
            if qrcode and base64 and rec.invoice_number:
                try:
                    qr = qrcode.QRCode(
                        version=1,
                        error_correction=qrcode.constants.ERROR_CORRECT_L,
                        box_size=10,
                        border=4,
                    )
                    qr.add_data(rec.invoice_number)
                    qr.make(fit=True)
                    img = qr.make_image()
                    temp = BytesIO()
                    img.save(temp, format="PNG")
                    qr_image = base64.b64encode(temp.getvalue())
                    rec.qr_code = qr_image
                except Exception:
                    _logger.exception("Error generating QR code for POS order %s", rec.id)
                    rec.qr_code = False
            else:
                rec.qr_code = False

    # =====================================================================
    # ONLINE PRA/FBR CALL (FROM POS JS)
    # =====================================================================
    @api.model
    def post_data_fbi(self, pos_order_data):
        """
        Called from POS JS (PaymentScreen) with a single ui_order dict
        built by buildFbrUiOrder(), or a list of such dicts.
        """
        header = {"Content-Type": "application/json"}
        invoice_number = ''
        response_data = {}

        # Normalize to list of dicts, like old pos_order_data_list behaviour
        if isinstance(pos_order_data, dict):
            orders = [pos_order_data]
        else:
            orders = pos_order_data or []

        Log = self.env['sh.fbr.log'].sudo()

        for ui_order in orders:
            fbr_log_id = False
            order_dic = {}
            try:
                pos_name = ui_order.get('name')          # can be "/"        # POS unique id



                unique_id = ui_order.get('uuid') or pos_name






                # ----------- BASIC AMOUNTS -----------
                amount_total = ui_order.get('amount_total', 0.0)
                amount_tax = ui_order.get('amount_tax', 0.0)
                total_discount = ui_order.get('total_discount') or 0.0
                sale_value = amount_total - amount_tax
                usin =ui_order.get("uuid")

                order_dic = {
                    "InvoiceNumber": "",
                    "USIN": ui_order.get('uuid'),
                    "DateTime": (fields.Datetime.now() + timedelta(hours=5)).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    ),
                    "TotalSaleValue": round(sale_value, 2),
                    "TotalTaxCharged": round(amount_tax, 2),
                    "TotalBillAmount": round(amount_total, 2),
                    "Discount": total_discount,
                    "RefUSIN": "",
                    "FurtherTax": 0.0,
                }

                for field in ['TotalBillAmount', 'TotalTaxCharged', 'TotalSaleValue']:
                    if order_dic[field] < 0:
                        order_dic[field] *= -1

                order_dic['InvoiceType'] = 3 if amount_total < 0 else 1

                # ----------- PAYMENT MODE -----------
                if ui_order.get('statement_ids'):
                    stm = ui_order['statement_ids'][0][2]
                    payment_method_id = stm.get('payment_method_id')
                    if payment_method_id:
                        payment_method = self.env['pos.payment.method'].browse(
                            payment_method_id
                        )
                        order_dic['PaymentMode'] = payment_method.payment_mode or "1"

                # ----------- POS CONFIG -----------
                token = False
                pos_id = False
                fbr_url = False

                session = self.env['pos.session'].sudo().browse(
                    ui_order.get('pos_session_id')
                )
                if session and session.config_id:
                    config = session.config_id
                    fbr_url = self._get_fbr_url(config)
                    header.update({'Authorization': f"Bearer {config.fbr_authorization}"})
                    token = config.fbr_authorization
                    pos_id = config.pos_id
                    order_dic['POSID'] = config.pos_id

                # ----------- PARTNER DATA -----------
                if ui_order.get('partner_id'):
                    partner = self.env['res.partner'].sudo().browse(
                        ui_order['partner_id']
                    )
                    order_dic.update(self._get_partner_data(partner))

                # ----------- ORDER LINES -----------
                order_dic.update(
                    self._process_order_lines(ui_order.get('lines', []))
                )

                # We no longer reuse existing logs here; always send fresh data
                _logger.info(
                    "PRA/FBR ONLINE: creating log for %s", pos_name
                )
                fbr_log_id = Log.create({
                    'name': usin or pos_name or unique_id,
                    'fbr_request': json.dumps(order_dic),
                })

                if not fbr_url or not token or not pos_id:
                    error_data = {
                        "error": "Missing FBR configuration (url/token/pos_id)",
                        "pos_id": pos_id,
                        "fbr_url": fbr_url,
                    }
                    if fbr_log_id:
                        fbr_log_id.write({
                            'fbr_response': error_data,
                            'posted_succesfull': False,
                        })
                    _logger.warning(
                        "PRA/FBR ONLINE: config missing for %s -> %s",
                        pos_name,
                        error_data,
                    )
                    return [2, json.dumps(order_dic), error_data]

                payload = {
                    "company": self.env.company.name,
                    "url": fbr_url,
                    "POSID": pos_id,
                    "unique_id": unique_id,
                    "data": order_dic,
                    "token": token,
                }

                _logger.info(
                    "PRA/FBR ONLINE REQUEST payload for %s: %s",
                    pos_name,
                    payload,
                )

                payment_response = requests.post(
                    "https://tax.trionex.pk/api/fbr",
                    json=payload,
                    verify=False,
                    timeout=20,
                )
                _logger.info(
                    "PRA/FBR ONLINE HTTP STATUS for %s: %s",
                    pos_name,
                    payment_response.status_code,
                )

                r_json = payment_response.json()
                _logger.info(
                    "PRA/FBR ONLINE RESPONSE JSON for %s: %s",
                    pos_name,
                    r_json,
                )

                status_code = r_json.get('statusCode')
                if status_code == 200:
                    data_response = r_json.get("data") or {}
                    response_data = fbr_data = data_response.get("fbr", {})
                    invoice_number = fbr_data.get('InvoiceNumber')

                    _logger.info(
                        "PRA/FBR ONLINE SUCCESS for %s: invoice_number=%s",
                        pos_name,
                        invoice_number,
                    )

                    if fbr_log_id:
                        fbr_log_id.write({
                            'fbr_response': fbr_data,
                            'fbr_invoice_number': invoice_number,
                            'posted_succesfull': True,
                        })

                    # Online call happens before order is created,
                    # so this search may not always find it; that's OK.
                    order_obj = self.search(
                        [('pos_reference', '=', pos_name)],
                        limit=1,
                    )
                    if order_obj:
                        order_obj.write({
                            'fbr_respone': fbr_data,
                            'post_data_fbr': True,
                            'invoice_number': invoice_number,
                            'fbr_request': json.dumps(order_dic),
                        })

                    return [1, invoice_number, json.dumps(order_dic), response_data]
                else:
                    fbr_data = r_json.get("fbr") or r_json
                    _logger.warning(
                        "PRA/FBR ONLINE FAILED for %s: %s",
                        pos_name,
                        fbr_data,
                    )
                    if fbr_log_id:
                        fbr_log_id.write({
                            'fbr_response': fbr_data,
                            'posted_succesfull': False,
                        })
                    return [2, json.dumps(order_dic), fbr_data]

            except Exception:
                error_data = {
                    'exception': traceback.format_exc(),
                }
                _logger.exception(
                    "PRA/FBR ONLINE ERROR for POS order %s",
                    ui_order.get('name'),
                )

                if fbr_log_id:
                    fbr_log_id.write({
                        'fbr_response': error_data,
                        'posted_succesfull': False,
                    })

                return [2, json.dumps(order_dic or {}), error_data]

        _logger.warning("PRA/FBR ONLINE: called with no orders / empty data")
        return [1, invoice_number, json.dumps({}), response_data]

    # =====================================================================
    # HELPER METHODS
    # =====================================================================
    def _get_fbr_url(self, config):
        if config.sh_fbr_authentication_type == 'sand_box':
            return 'https://esp.fbr.gov.pk:8244/FBR/v1/api/Live/PostData'
        return 'https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData'

    def _get_partner_data(self, partner):
        data = {"BuyerName": partner.name}
        # if partner.mobile:
        #     data["BuyerPhoneNumber"] = partner.mobile
        if partner.vat:
            data["BuyerCNIC"] = partner.vat
        if partner.ntn:
            data["BuyerNTN"] = partner.ntn
        return data

    def _process_order_lines(self, lines):
        items = []
        totals = {
            'quantity': 0.0,
            'sale_value': 0.0,
            'tax_charged': 0.0,
            'bill_amount': 0.0,
            'discount': 0.0,
        }

        children_by_parent = defaultdict(list)
        for line in lines:
            line_data = line[2]
            parent_id = line_data.get("combo_parent_id")
            if parent_id:
                children_by_parent[parent_id].append(line_data)

        for line in lines:
            line_data = line[2]
            product = self.env['product.product'].browse(line_data['product_id'])

            if product.product_tmpl_id.hide_for_request:
                if not line_data.get('combo_parent_id', 0):
                    qty = abs(line_data.get('qty', 0))
                    price_unit = abs(line_data.get('price_unit', 0))

                    if line_data.get("id") in children_by_parent:
                        child_lines = children_by_parent[line_data["id"]]
                        subtotal = sum(c.get("price_subtotal", 0) for c in child_lines)
                        subtotal_incl = sum(
                            c.get("price_subtotal_incl", 0) for c in child_lines
                        )

                        tax_charged = subtotal_incl - subtotal
                        if subtotal > 0:
                            effective_tax_rate = (tax_charged / subtotal) * 100
                        else:
                            effective_tax_rate = 0.0
                    else:
                        subtotal = line_data.get("price_subtotal", 0)
                        subtotal_incl = line_data.get("price_subtotal_incl", 0)
                        tax_charged = subtotal_incl - subtotal
                        effective_tax_rate = self._get_tax_rate(line_data)

                    tax_charged = abs(subtotal_incl - subtotal)
                    sale_value = abs(subtotal)
                    discount = self._calculate_discount(
                        product, qty, price_unit, line_data
                    )

                    item = {
                        "ItemCode": product.default_code,
                        "ItemName": product.name,
                        "Quantity": qty,
                        "PCTCode": product.pct_code,
                        "TaxRate": round(effective_tax_rate, 2),
                        "SaleValue": round(sale_value, 2),
                        "TaxCharged": round(tax_charged, 2),
                        "TotalAmount": round(abs(subtotal_incl), 2),
                        "Discount": round(discount, 2),
                        "InvoiceType": 3 if subtotal_incl < 0 else 1,
                        "FurtherTax": 0.0,
                    }

                    items.append(item)
                    bill_amount = subtotal_incl
                    self._update_totals(
                        totals,
                        qty,
                        sale_value,
                        tax_charged,
                        bill_amount,
                        discount,
                    )

        return {
            'Items': items,
            'TotalQuantity': round(totals['quantity'], 2),
            'TotalSaleValue': round(totals['sale_value'], 2),
            'TotalTaxCharged': round(totals['tax_charged'], 2),
            'TotalBillAmount': round(totals['bill_amount'], 2),
            'Discount': round(totals['discount'], 2),
        }

    def _calculate_discount(self, product, qty, price_unit, line_data):
        return line_data.get('discount')

    def _get_tax_rate(self, line_data):
        try:
            if line_data.get('tax_ids'):
                tax = self.env['account.tax'].browse(
                    line_data['tax_ids'][0][2][0]
                )
                return round(tax.amount, 2)
            return 0.0
        except Exception:
            return 0.0

    def _update_totals(
        self,
        totals,
        qty,
        sale_value,
        tax_charged,
        bill_amount,
        discount,
    ):
        totals['quantity'] += qty
        totals['sale_value'] += sale_value
        totals['tax_charged'] += tax_charged
        totals['bill_amount'] += bill_amount
        totals['discount'] += discount

    # =====================================================================
    # CRON / OFFLINE POSTING (unchanged original behaviour, but with safe RefUSIN)
    # =====================================================================
    def post_data_to_fbr_cron(self):
        for failed_orders in self.search([('post_data_fbr', '=', False)], limit=10):
            failed_orders.post_data_to_fbr_action()

    def post_data_to_fbr_action(self):
        orders = []
        Log = self.env['sh.fbr.log'].sudo()

        for order in self:
            if not order.post_data_fbr:
                fbr_log_id = Log.search(
                    [
                        ('name', '=', order.pos_reference),
                        ('posted_succesfull', '=', True),
                        (
                            'fbr_invoice_number',
                            'not in',
                            [False, 'Not Available', 'No Avaialble'],
                        ),
                    ]
                )
                if len(fbr_log_id) == 0:
                    orders.append(order.id)
                else:
                    order.write({
                        'fbr_respone': fbr_log_id[0].fbr_response,
                        'post_data_fbr': True,
                        'invoice_number': fbr_log_id[0].fbr_invoice_number,
                        'fbr_request': fbr_log_id[0].fbr_request,
                    })
        if len(orders) > 0:
            self.post_data_to_fbr(orders)

    def post_data_to_fbr(self, orders):
        header = {"Content-Type": "application/json"}
        Log = self.env['sh.fbr.log'].sudo()

        for order_id in orders:
            order = self.browse(order_id)
            fbr_log_id = False
            order_dic = {}

            try:
                if (
                    order
                    and order.session_id
                    and order.session_id.config_id
                    and order.session_id.config_id.sh_enable_fbr_connector_feature
                    and order.session_id.config_id.fbr_authorization
                ):
                    config = order.session_id.config_id
                    if config.sh_fbr_authentication_type == 'sand_box':
                        fbr_url = (
                            'https://ims.pral.com.pk/ims/sandbox/api/Live/PostData'
                        )
                    elif config.sh_fbr_authentication_type == 'production':
                        fbr_url = (
                            'https://ims.pral.com.pk/ims/production/api/Live/PostData'
                        )
                    else:
                        fbr_url = False

                    header.update(
                        {
                            'Authorization': "Bearer "
                            + order.session_id.config_id.fbr_authorization
                        }
                    )

                    bill_amount = order.amount_total
                    tax_amount = order.amount_tax
                    sale_amount = order.amount_total - order.amount_tax

                    order_dic = {
                        "InvoiceNumber": "",
                        "POSID": order.session_id.config_id.pos_id,
                        "USIN": order.pos_reference or "",
                        "DateTime": (
                            (order.date_order) + timedelta(hours=5)
                        ).strftime("%Y-%m-%d %H:%M:%S"),
                        "TotalBillAmount": round(bill_amount, 2),
                        "TotalSaleValue": round(sale_amount, 2),
                        "TotalTaxCharged": round(tax_amount, 2),
                        "RefUSIN": order.old_pos_reference
                        or order.pos_reference
                        or "",
                        "Discount": round(order.total_discount, 2),
                        "FurtherTax": 0.0,
                    }

                    if bill_amount < 0.0:
                        order_dic['TotalBillAmount'] = (-1) * bill_amount
                    if sale_amount < 0.0:
                        order_dic['TotalSaleValue'] = (-1) * sale_amount
                    if tax_amount < 0.0:
                        order_dic['TotalTaxCharged'] = (-1) * tax_amount
                    if order.total_discount < 0.0:
                        order_dic['Discount'] = (-1) * order.total_discount

                    if order.amount_total >= 0:
                        order_dic['InvoiceType'] = 1
                    else:
                        order_dic['InvoiceType'] = 3

                    if order.payment_ids and order.payment_ids[0].payment_method_id:
                        mode = order.payment_ids[
                            0
                        ].payment_method_id.payment_mode
                        if mode in ["1", "2", "3", "4", "5", "6"]:
                            order_dic['PaymentMode'] = mode

                    if order.partner_id:
                        order_dic.update({
                            "BuyerName": order.partner_id.name,
                        })
                        if order.partner_id.mobile:
                            order_dic["BuyerPhoneNumber"] = (
                                order.partner_id.mobile
                            )
                        if order.partner_id.vat:
                            order_dic["BuyerCNIC"] = order.partner_id.vat
                        if order.partner_id.ntn:
                            order_dic["BuyerNTN"] = order.partner_id.ntn

                    if order.lines:
                        items_list = []
                        total_qty = 0.0
                        total_sale_value = 0.0
                        total_tax_charged = 0.0
                        total_bill_amount = 0.0

                        children_by_parent = defaultdict(list)
                        for line in order.lines:
                            parent_id = line.combo_parent_id
                            if parent_id:
                                children_by_parent[parent_id.id].append(line)

                        for line in order.lines:
                            if line.combo_parent_id:
                                continue

                            if (
                                line.product_id
                                and line.product_id.product_tmpl_id.hide_for_request
                            ):
                                total_qty += line.qty
                                qty = abs(line.qty)
                                price_unit = abs(line.price_unit)

                                line_invoice_type = 1
                                if line.price_subtotal_incl < 0.0:
                                    line_invoice_type = 3

                                if line.id in children_by_parent:
                                    child_lines = children_by_parent[line.id]
                                    price_subtotal = sum(
                                        c.price_subtotal for c in child_lines
                                    )
                                    price_subtotal_incl = sum(
                                        c.price_subtotal_incl
                                        for c in child_lines
                                    )
                                    tax_charged = (
                                        price_subtotal_incl - price_subtotal
                                    )
                                else:
                                    price_subtotal = abs(
                                        line.price_subtotal_incl
                                    )
                                    price_subtotal_incl = round(
                                        line.price_subtotal_incl, 2
                                    )
                                    tax_charged = (
                                        price_subtotal_incl - price_subtotal
                                    )

                                tax_charged = abs(
                                    price_subtotal_incl - price_subtotal
                                )
                                if tax_charged < 0.0:
                                    tax_charged = (-1) * tax_charged

                                total_bill_amount += price_subtotal_incl
                                total_tax_charged += round(tax_charged, 2)
                                total_sale_value += round(
                                    price_subtotal_incl
                                    - round(tax_charged, 2),
                                    2,
                                )

                                line_dic = {
                                    "ItemCode": line.product_id.default_code,
                                    "ItemName": line.product_id.name,
                                    "Quantity": qty,
                                    "PCTCode": line.product_id.pct_code,
                                    "TaxRate": round(
                                        ((qty * price_unit) - price_subtotal),
                                        2,
                                    ),
                                    "SaleValue": round(
                                        price_subtotal - tax_charged, 2
                                    ),
                                    "TotalAmount": round(
                                        price_subtotal, 2
                                    ),
                                    "TaxCharged": round(
                                        tax_charged, 2
                                    ),
                                    "InvoiceType": line_invoice_type,
                                    "RefUSIN": "",
                                    "Discount": 0.0,
                                    "FurtherTax": 0.0,
                                }

                                if line.tax_ids:
                                    tax_rate = round(
                                        line.tax_ids[0].amount, 2
                                    )
                                    line_dic.update({'TaxRate': tax_rate})

                                items_list.append(line_dic)

                        if total_qty < 0.0:
                            total_qty = (-1) * total_qty
                        if total_sale_value < 0.0:
                            total_sale_value = (-1) * total_sale_value
                        if total_tax_charged < 0.0:
                            total_tax_charged = (-1) * total_tax_charged
                        if total_bill_amount < 0.0:
                            total_bill_amount = (-1) * total_bill_amount

                        order_dic.update({
                            'Items': items_list,
                            'TotalQuantity': total_qty,
                            "TotalSaleValue": round(total_sale_value, 2),
                            "TotalTaxCharged": round(
                                total_tax_charged, 2
                            ),
                            "TotalBillAmount": round(
                                total_bill_amount, 2
                            ),
                        })
                        fbr_log_id = Log.create({
                            'name': order.pos_reference,
                            'fbr_request': json.dumps(order_dic),
                        })

                    payload = {
                        "company": self.env.company.name,
                        "url": fbr_url,
                        "POSID": order.session_id.config_id.pos_id,
                        "unique_id": order.pos_reference,
                        "data": order_dic,
                        "token": order.session_id.config_id.fbr_authorization,
                    }

                    payment_response = requests.post(
                        "https://tax.trionex.pk/api/fbr",
                        json=payload,
                        verify=False,
                        timeout=20,
                    )
                    r_json = payment_response.json()
                    if r_json.get('statusCode') == 200:
                        data_response = r_json.get("data") or {}
                        fbr_data = data_response.get("fbr", {})
                        invoice_number = fbr_data.get('InvoiceNumber')

                        if fbr_log_id:
                            fbr_log_id.write(
                                {
                                    'fbr_response': fbr_data,
                                    'fbr_invoice_number': invoice_number,
                                    'posted_succesfull': True,
                                }
                            )

                        order.write({
                            'fbr_respone': fbr_data,
                            'post_data_fbr': True,
                            'invoice_number': invoice_number,
                            'fbr_request': json.dumps(order_dic),
                        })
                    else:
                        fbr_data = r_json.get("fbr") or r_json
                        if fbr_log_id:
                            fbr_log_id.write(
                                {
                                    'fbr_response': fbr_data,
                                    'posted_succesfull': False,
                                }
                            )
                        order.write(
                            {
                                'fbr_respone': fbr_data,
                                'fbr_request': json.dumps(order_dic),
                            }
                        )

            except Exception:
                values = dict(
                    exception=traceback.format_exc(),
                )
                _logger.exception(
                    "PRA/FBR OFFLINE ERROR for order %s",
                    order.pos_reference,
                )
                if fbr_log_id:
                    fbr_log_id.write(
                        {'fbr_response': values, 'posted_succesfull': False}
                    )
                order.write(
                    {
                        'fbr_respone': values,
                        'fbr_request': json.dumps(order_dic or {}),
                    }
                )

    # =====================================================================
    # SYNC UI → ORDER FIELDS
    # =====================================================================
    @api.model
    def _order_fields(self, ui_order):
        res = super(POSOrder, self)._order_fields(ui_order)
        res['invoice_number'] = ui_order.get('invoice_number', False)
        res['post_data_fbr'] = ui_order.get('post_data_fbr', False)
        res['fbr_respone'] = ui_order.get('fbr_respone', False)
        res['fbr_request'] = ui_order.get('fbr_request', False)
        _logger.info(
            "UI Order total_discount -> %s",
            ui_order.get('total_discount', 0.00),
        )
        res['total_discount'] = ui_order.get('total_discount', 0.00)
        if ui_order.get('sh_include_service_fee'):
            res['sh_include_service_fee'] = ui_order.get(
                'sh_include_service_fee', False
            )
            res['sh_service_fee'] = ui_order.get(
                'sh_service_fee', False
            )
        return res
