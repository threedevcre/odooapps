# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.
from odoo import fields, models, api, _
import requests
import json
import traceback
from odoo.exceptions import UserError
from datetime import timedelta

try:
    import qrcode
except ImportError:
    qrcode = None
try:
    import base64
except ImportError:
    base64 = None

from io import BytesIO
from datetime import timedelta, datetime, time

import logging

_logger = logging.getLogger(__name__)


class POSOrder(models.Model):
    _inherit = 'pos.order'

    fbr_request = fields.Text("FBR Request")
    fbr_respone = fields.Text("FBR Response")
    post_data_fbr = fields.Boolean("Post Data Successful ?")
    pos_reference = fields.Char(string='Receipt Ref', readonly=True, copy=True)
    invoice_number = fields.Char("Invoice Number")
    sh_include_service_fee = fields.Boolean(string="Include Service Fee")
    sh_service_fee = fields.Float(string="Service Fee")
    total_discount = fields.Float(string="Total Discount")
    not_available_in_portal = fields.Boolean(string="Not Available in Portal")

    pos_receipt_header = fields.Text(string='Receipt Header', readonly=False, store=True)
    pos_receipt_footer = fields.Text(string='Receipt Footer', readonly=False, store=True)
    qr_code = fields.Binary('QRcode', compute="_generate_qr")

    def _generate_qr(self):
        for rec in self:
            if qrcode and base64:
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                    box_size=10,
                    border=4,
                )
                qr.add_data(rec.invoice_number)
                qr.make(fit=True)
                img = qr.make_image()
                temp = BytesIO()
                img.save(temp, format="PNG")
                qr_image = base64.b64encode(temp.getvalue())
                rec.update({'qr_code': qr_image})

    def post_data_fbi(self, pos_order_data):
        header = {"Content-Type": "application/json"}
        pos_name = ''
        invoice_number = ''
        r_json = False
        fbr_log_id = False
        not_push_to_fbr = False
        if pos_order_data:
            print('\n\n\n >>>>pos_order_data>>>> ', pos_order_data)
            try:
                for pos_order in pos_order_data:
                    pos_name = pos_order['name']
                    order_dic = {
                        "InvoiceNumber": "",
                        "USIN": pos_order.get('name'),
                        "DateTime": (fields.Datetime.now() + timedelta(hours=5)).strftime("%Y-%m-%d %H:%M:%S"),
                        "TotalSaleValue": round(pos_order.get('amount_total') - pos_order.get('amount_tax'), 2),
                        "TotalTaxCharged": round(pos_order.get('amount_tax'), 2),
                        "TotalBillAmount": round(pos_order.get('amount_total'), 2),
                        "Discount": pos_order.get('total_discount') or 0.00,
                        "RefUSIN": pos_order.get('old_pos_reference') if pos_order.get('old_pos_reference') not in (
                            None, False, 'false', 'None', 'null') else "",
                        "FurtherTax": 0.0,
                    }

                    if pos_order.get('amount_total') < 0.0:
                        order_dic['TotalBillAmount'] = (-1) * \
                                                       pos_order.get('amount_total')

                    if pos_order.get('amount_tax') < 0.0:
                        order_dic['TotalTaxCharged'] = (-1) * \
                                                       pos_order.get('amount_tax')

                    if (pos_order.get('amount_total') - pos_order.get('amount_tax')) < 0.0:
                        order_dic['TotalSaleValue'] = (-1) * (pos_order.get(
                            'amount_total') - pos_order.get('amount_tax'))

                    invoice_type = 1

                    if pos_order.get('amount_total'):
                        if pos_order.get('amount_total') >= 0:
                            order_dic['InvoiceType'] = 1
                        elif pos_order.get('amount_total') < 0:
                            order_dic['InvoiceType'] = 3
                            invoice_type = 3

                    if pos_order.get('statement_ids'):
                        if pos_order.get('statement_ids')[0] and pos_order.get('statement_ids')[0][2] and \
                                pos_order.get('statement_ids')[0][2]['payment_method_id']:
                            payment_obj = self.env['pos.payment.method'].search(
                                [('id', '=', pos_order.get('statement_ids')[0][2]['payment_method_id'])])
                            if payment_obj and payment_obj.payment_mode:
                                not_push_to_fbr = payment_obj.not_push_to_fbr
                                mode = payment_obj.payment_mode
                                if mode == "1":
                                    order_dic['PaymentMode'] = "1"
                                elif mode == "2":
                                    order_dic['PaymentMode'] = "2"
                                elif mode == "3":
                                    order_dic['PaymentMode'] = "3"
                                elif mode == "4":
                                    order_dic['PaymentMode'] = "4"
                                elif mode == "5":
                                    order_dic['PaymentMode'] = "5"
                                elif mode == "6":
                                    order_dic['PaymentMode'] = "6"

                    session = self.env['pos.session'].sudo().search(
                        [('id', '=', pos_order.get('pos_session_id'))])
                    token = False
                    pos_id = False
                    session = self.env['pos.session'].sudo().browse(pos_order.get('pos_session_id'))
                    if session and session.config_id:
                        config = session.config_id
                        if config.sh_fbr_authentication_type:
                            if config.sh_fbr_authentication_type == 'sand_box':
                                fbr_url = "https://esp.fbr.gov.pk:8244/FBR/v1/api/Live/PostData"
                            elif config.sh_fbr_authentication_type == 'production':
                                fbr_url = "https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData"
                            elif config.sh_fbr_authentication_type == 'custom':
                                fbr_url = config.fbr_url
                            elif config.sh_fbr_authentication_type == 'microservice':
                                fbr_url = "https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData"
                        header.update(
                            {'Authorization': "Bearer " + session.config_id.fbr_authorization})
                        order_dic.update({'POSID': session.config_id.pos_id})
                        pos_id = config.pos_id
                        token = config.fbr_authorization

                    if pos_order.get('partner_id'):
                        partner = self.env['res.partner'].sudo().browse(pos_order.get('partner_id'))

                        order_dic.update({
                            "BuyerName": partner.name,
                        })
                        if partner.mobile:
                            order_dic.update({
                                "BuyerPhoneNumber": partner.mobile,
                            })
                        if partner.vat:
                            order_dic.update({
                                "BuyerCNIC": partner.vat,
                            })
                        if partner.ntn:
                            order_dic.update({
                                "BuyerNTN": partner.ntn,
                            })

                    total_discount = 0
                    if pos_order.get('lines'):

                        items_list = []
                        total_qty = 0.0
                        total_sale_value = 0.0
                        total_tax_charged = 0.0
                        total_bill_amount = 0.0

                        for line in pos_order.get('lines'):
                            product_dic = line[2]
                            if 'product_id' in product_dic:
                                product = self.env['product.product'].sudo().browse(product_dic.get('product_id'))
                                total_qty += product_dic.get('qty')
                                qty = product_dic.get('qty')
                                price_unit = product_dic.get('price_unit')
                                if product_dic.get('qty') < 0:
                                    if price_unit == product.lst_price and product_dic.get('discount') > 0:
                                        discount_line = round(
                                            (qty * (product.lst_price * (product_dic.get('discount') / 100))),
                                            2) if product_dic.get('discount') > 0 else 0
                                    else:
                                        discount_line = round((qty * (product.lst_price * round(
                                            (1 - (price_unit / product.lst_price)), 2))),
                                                              2) if price_unit != 0 and product.lst_price != 0 else 0
                                    qty = (-1) * qty
                                else:
                                    discount_line = round((qty * (
                                                product.lst_price * round((1 - (price_unit / product.lst_price)),
                                                                          2))),
                                                          2) if price_unit != 0 and product.lst_price != 0 else 0
                                if price_unit < 0.0:
                                    price_unit = (-1) * price_unit

                                price_subtotal = product_dic.get('price_subtotal_incl')
                                if price_subtotal < 0.0:
                                    price_subtotal = (-1) * price_subtotal
                                price_subtotal_incl = round(product_dic.get('price_subtotal_incl'), 2)
                                total_bill_amount += price_subtotal_incl
                                line_invoice_type = 1
                                tax_charged = product_dic.get('price_subtotal_incl') - product_dic.get(
                                    'price_subtotal')
                                total_tax_charged += round(tax_charged, 2)
                                total_sale_value += round(price_subtotal_incl - round(tax_charged, 2), 2)
                                if price_subtotal_incl < 0.0:
                                    line_invoice_type = 3
                                    price_subtotal_incl = (-1) * price_subtotal_incl
                                if tax_charged < 0.0:
                                    tax_charged = (-1) * tax_charged
                                total_discount += discount_line
                                if discount_line < 0.0:
                                    discount_line = (-1) * discount_line

                                line_dic = {
                                    "ItemCode": product.default_code,
                                    "ItemName": product.name,
                                    "Quantity": qty,
                                    "PCTCode": product.pct_code,
                                    "TaxRate": round(((qty * price_unit) - price_subtotal), 2),
                                    "SaleValue": round(price_subtotal_incl - round(tax_charged, 2), 2),
                                    "TaxCharged": round(tax_charged, 2),
                                    "TotalAmount": round(price_subtotal_incl, 2),
                                    "Discount": discount_line,
                                    "InvoiceType": line_invoice_type,
                                    "RefUSIN": pos_order.get('old_pos_reference') if pos_order.get(
                                        'old_pos_reference') not in (None, False, 'false', 'None', 'null') else "",
                                    "FurtherTax": 0.0,
                                }

                                tax_ids = product_dic.get('tax_ids')
                                if len(tax_ids[0][2]) > 0:
                                    tax_id = tax_ids[0][2][0]
                                    tax_rec = self.env['account.tax'].sudo().browse(int(tax_id))
                                    tax_rate = round(tax_rec.amount, 2)
                                    line_dic.update({'TaxRate': tax_rate})

                                items_list.append(line_dic)

                        if total_qty < 0.0:
                            total_qty = (-1) * total_qty
                        if total_sale_value < 0.0:
                            total_sale_value = (-1) * total_sale_value
                        if total_tax_charged < 0.0:
                            total_tax_charged = (-1) * total_tax_charged
                        if total_bill_amount < 0.0:
                            total_bill_amount = (-1) * total_bill_amount
                        order_dic.update(
                            {
                                'Items': items_list,
                                'TotalQuantity': total_qty,
                                "TotalSaleValue": round(total_sale_value, 2),
                                "TotalTaxCharged": round(total_tax_charged, 2),
                                "TotalBillAmount": round(total_bill_amount, 2)
                            }
                        )
                    if total_discount < 0.0:
                        total_discount = (-1) * total_discount
                    order_dic['Discount'] = total_discount

                    fbr_log_id = self.env['sh.fbr.log'].create({
                        'name': pos_order['name'],
                        'fbr_request': json.dumps(order_dic)
                    })
                    print('\n\n\n fbr_log_id ---> ', fbr_log_id)
                if not not_push_to_fbr:
                    print('Request Time', datetime.now())
                    payment_response = requests.post(
                        "https://tax.trionex.pk/api/fbr",
                        json={
                            "company": self.env.company.name,
                            "url": fbr_url,
                            "POSID": pos_id,
                            "unique_id": pos_name,
                            "data": order_dic,
                            "token": token,
                            "force_fbr_push": False
                        },
                        verify=False,
                        timeout=120)
                    print('Receiving Time', datetime.now())
                    print(payment_response)
                    r_json = payment_response.json()
                    _logger.info("Response: %s - %s", str(r_json.get('statusCode')), str(r_json))
                    if r_json.get('statusCode') == 200:
                        data_response = r_json.get("data")
                        print(data_response)
                        response_data = fbr_data = data_response.get("fbr")
                        print(fbr_data)
                        invoice_number = fbr_data.get('InvoiceNumber')
                        _logger.info("Successful FBR post: InvoiceNumber %s", invoice_number)
                        print(invoice_number)
                        if fbr_log_id:
                            fbr_log_id.write({
                                'fbr_response': fbr_data,
                                'fbr_invoice_number': invoice_number,
                                'posted_succesfull': True
                            })
                        order_obj = self.search([('pos_reference', '=', pos_order['name'])])
                        if order_obj:
                            order_obj.write({
                                'fbr_response': fbr_data,
                                'post_data_fbr': True,
                                'invoice_number': invoice_number,
                                'fbr_request': json.dumps(order_dic)
                            })
                        print('Closing Time', datetime.now())
                        return [1, invoice_number, json.dumps(order_dic), response_data]
                    else:
                        if fbr_log_id:
                            fbr_log_id.write(
                                {'fbr_response': str(r_json),
                                 'posted_succesfull': False})
                        print('Closing Time', datetime.now())
                        return [2, json.dumps(order_dic), str(r_json)]
                #     payment_response = requests.post(fbr_url, data=json.dumps(
                #         order_dic), headers=header, verify=False, timeout=20)
                #     r_json = payment_response.json()
                #     invoice_number = r_json.get('InvoiceNumber')
                #
                #     if fbr_log_id:
                #         fbr_log_id.write(
                #             {'fbr_response': r_json, 'fbr_invoice_number': invoice_number, 'posted_succesfull': True})
                #
                #     if order_obj:
                #         order_obj.write({'fbr_respone': r_json, 'post_data_fbr': True,
                #                          'invoice_number': invoice_number, 'fbr_request': json.dumps(order_dic)})
                # else:
                #     return [2, json.dumps(order_dic), {}]
            except Exception as e:
                values = dict(
                    exception=e,
                    traceback=traceback.format_exc(),
                )
                if fbr_log_id:
                    fbr_log_id.write(
                        {'fbr_response': values, 'posted_succesfull': False})

                print('\n\n\n -----------> ', [2, json.dumps(order_dic), values])
                return [2, json.dumps(order_dic), values]
        print('\n\nn\ ?????????? ', pos_order_data)
        return [1, invoice_number, json.dumps(order_dic), r_json]

    def post_data_to_fbr_cron(self, process=False):
        if process:
            for failed_orders in self.search([('post_data_fbr', '=', False)]):
                failed_orders.post_data_to_fbr_action()

    def post_data_to_fbr_action(self, process=False):
        if process:
            orders = []
            for order in self:
                if not order.post_data_fbr:
                    fbr_log_id = self.env['sh.fbr.log'].search([
                        ('name', '=', order.pos_reference),
                        ('posted_succesfull', '=', True),
                        ('fbr_invoice_number', 'not in', [False, 'Not Available', 'No Avaialble']),
                    ])
                    if len(fbr_log_id) == 0:
                        orders.append(order.id)
                    else:
                        order.write({
                            'fbr_respone': fbr_log_id[0].fbr_response,
                            'post_data_fbr': True,
                            'invoice_number': fbr_log_id[0].fbr_invoice_number,
                            'fbr_request': fbr_log_id[0].fbr_request
                        })
            print(orders)
            if len(orders) > 0:
                self.post_data_to_fbr(orders, process=process)

    def post_data_to_fbr(self, orders, process=False):
        if process:
            header = {"Content-Type": "application/json"}
            for order in orders:
                order = self.browse(order)
                try:
                    not_push_to_fbr = order.payment_ids and order.payment_ids[0].payment_method_id.not_push_to_fbr
                    if order and order.session_id and order.session_id.config_id and order.session_id.config_id.sh_enable_fbr_connector_feature and order.session_id.config_id.fbr_authorization and not not_push_to_fbr:
                        config = order.session_id.config_id
                        if config.sh_fbr_authentication_type:
                            if config.sh_fbr_authentication_type == 'sand_box':
                                fbr_url = "https://esp.fbr.gov.pk:8244/FBR/v1/api/Live/PostData"
                            elif config.sh_fbr_authentication_type == 'production':
                                fbr_url = "https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData"
                            elif config.sh_fbr_authentication_type == 'custom':
                                fbr_url = config.fbr_url
                            elif config.sh_fbr_authentication_type == 'microservice':
                                fbr_url = "https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData"
                        if fbr_url:
                            header.update(
                                {'Authorization': "Bearer " + order.session_id.config_id.fbr_authorization})

                            bill_amount = order.amount_total
                            tax_amount = order.amount_tax
                            sale_amount = order.amount_total - order.amount_tax
                            order_dic = {
                                "InvoiceNumber": "",
                                "POSID": order.session_id.config_id.pos_id,
                                "USIN": order.pos_reference,
                                "DateTime": ((order.date_order) + timedelta(hours=5)).strftime("%Y-%m-%d %H:%M:%S"),
                                "TotalBillAmount": round(bill_amount, 2),
                                "TotalSaleValue": round(sale_amount, 2),
                                "TotalTaxCharged": round(tax_amount, 2),
                                "RefUSIN": order.old_pos_reference if order.old_pos_reference not in (None, False,
                                                                                                      'false', 'None',
                                                                                                      'null') else "",
                                "Discount": round(order.total_discount, 2),
                                "FurtherTax": 0.0,
                            }

                            if bill_amount < 0.0:
                                order_dic['TotalBillAmount'] = (-1) * bill_amount

                            if sale_amount < 0.0:
                                order_dic['TotalSaleValue'] = (-1) * sale_amount

                            if tax_amount < 0.0:
                                order_dic['TotalTaxCharged'] = (-1) * tax_amount

                            if order.amount_total:
                                if order.amount_total >= 0:
                                    order_dic['InvoiceType'] = 1
                                    invoice_type = 1
                                elif order.amount_total < 0:
                                    order_dic['InvoiceType'] = 3
                                    invoice_type = 3

                            if order.payment_ids:
                                if order.payment_ids and order.payment_ids[0].payment_method_id:
                                    mode = order.payment_ids[0].payment_method_id.payment_mode
                                    if mode == "1":
                                        order_dic['PaymentMode'] = "1"
                                    elif mode == "2":
                                        order_dic['PaymentMode'] = "2"
                                    elif mode == "3":
                                        order_dic['PaymentMode'] = "3"
                                    elif mode == "4":
                                        order_dic['PaymentMode'] = "4"
                                    elif mode == "5":
                                        order_dic['PaymentMode'] = "5"
                                    elif mode == "6":
                                        order_dic['PaymentMode'] = "6"

                            if order.partner_id:
                                order_dic.update({
                                    "BuyerName": order.partner_id.name,
                                })
                                if order.partner_id.mobile:
                                    order_dic.update({
                                        "BuyerPhoneNumber": order.partner_id.mobile,
                                    })
                                if order.partner_id.cnic:
                                    order_dic.update({
                                        "BuyerCNIC": order.partner_id.vat,
                                    })
                                if order.partner_id.ntn:
                                    order_dic.update({
                                        "BuyerNTN": order.partner_id.ntn,
                                    })

                            if order.lines:
                                items_list = []
                                total_qty = 0.0
                                total_sale_value = 0.0
                                total_tax_charged = 0.0
                                total_bill_amount = 0.0
                                total_discount_value = 0.0

                                for line in order.lines:
                                    total_qty += line.qty
                                    qty = line.qty

                                    price_unit = line.price_unit
                                    if price_unit < 0.0:
                                        price_unit = (-1) * price_unit

                                    price_subtotal = line.price_subtotal_incl
                                    line_invoice_type = 1
                                    if price_subtotal < 0.0:
                                        line_invoice_type = 3
                                        price_subtotal = (-1) * price_subtotal
                                    price_subtotal_incl = round(line.price_subtotal_incl, 2)
                                    total_bill_amount += price_subtotal_incl
                                    tax_charged = line.price_subtotal_incl - line.price_subtotal
                                    total_tax_charged += round(tax_charged, 2)
                                    total_sale_value += round(price_subtotal_incl - round(tax_charged, 2), 2)
                                    discount_line = round((qty * (price_unit * round((line.discount / 100), 2))),
                                                          2) if price_unit != 0 and line.discount > 0 else 0
                                    if qty < 0:
                                        qty = (-1) * qty
                                    total_discount_value += discount_line
                                    tax_charged = line.price_subtotal_incl - line.price_subtotal
                                    if tax_charged < 0.0:
                                        tax_charged = (-1) * tax_charged

                                    line_dic = {
                                        "ItemCode": line.product_id.default_code,
                                        "ItemName": line.product_id.name,
                                        "Quantity": qty,
                                        "PCTCode": line.product_id.pct_code,
                                        "TaxRate": round(((qty * price_unit) - price_subtotal), 2),
                                        "SaleValue": round(price_subtotal - tax_charged, 2),
                                        "TotalAmount": round(price_subtotal, 2),
                                        "TaxCharged": round(tax_charged, 2),
                                        "InvoiceType": line_invoice_type,
                                        "RefUSIN": order.old_pos_reference if order.old_pos_reference not in (None,
                                                                                                              False,
                                                                                                              'false',
                                                                                                              'None',
                                                                                                              'null') else "",
                                        "Discount": discount_line,
                                        "FurtherTax": 0.0,
                                    }
                                    if line.tax_ids:
                                        tax_rate = round(line.tax_ids[0].amount, 2)
                                        line_dic.update({'TaxRate': round(tax_rate, 2)})

                                    items_list.append(line_dic)

                                if total_qty < 0.0:
                                    total_qty = (-1) * total_qty
                                if total_sale_value < 0.0:
                                    total_sale_value = (-1) * total_sale_value
                                if total_tax_charged < 0.0:
                                    total_tax_charged = (-1) * total_tax_charged
                                if total_bill_amount < 0.0:
                                    total_bill_amount = (-1) * total_bill_amount
                                if total_discount_value < 0.0:
                                    total_discount_value = (-1) * total_discount_value
                                order_dic.update({
                                    'Items': items_list,
                                    'TotalQuantity': total_qty,
                                    "TotalSaleValue": round(total_sale_value, 2),
                                    "TotalTaxCharged": round(total_tax_charged, 2),
                                    "TotalBillAmount": round(total_bill_amount, 2),
                                    "Discount": round(total_discount_value, 2)
                                })
                                fbr_log_id = self.env['sh.fbr.log'].create({
                                    'name': order.pos_reference,
                                    'fbr_request': json.dumps(order_dic)
                                })
                                payment_response = requests.post(
                                    "https://tax.trionex.pk/api/fbr",
                                    # "http://192.168.110.100/fbr-middleware/public/api/fbr",
                                    # data=json.dumps(order_dic),
                                    json={
                                        "company": self.env.company.name,
                                        "url": fbr_url,
                                        "POSID": order.session_id.config_id.pos_id,
                                        "unique_id": order.pos_reference,
                                        "data": order_dic,
                                        "token": order.session_id.config_id.fbr_authorization,
                                        "force_fbr_push": order.not_available_in_portal
                                    },
                                    # headers=header,
                                    verify=False,
                                    timeout=120)
                                print(payment_response)
                                r_json = payment_response.json()
                                _logger.info("Response: %s - %s", str(r_json.get('statusCode')), str(r_json))
                                print(r_json)
                                if r_json.get('statusCode') == 200:
                                    data_response = r_json.get("data")
                                    print(data_response)
                                    fbr_data = data_response.get("fbr")
                                    print(fbr_data)
                                    invoice_number = fbr_data.get('InvoiceNumber')
                                    _logger.info("Successful FBR post: InvoiceNumber %s", invoice_number)
                                    print(invoice_number)
                                    if fbr_log_id:
                                        fbr_log_id.write(
                                            {'fbr_response': fbr_data, 'fbr_invoice_number': invoice_number,
                                             'posted_succesfull': True})

                                    order.write({'fbr_respone': fbr_data, 'post_data_fbr': True,
                                                 'invoice_number': invoice_number,
                                                 'fbr_request': json.dumps(order_dic)})
                                else:
                                    if fbr_log_id:
                                        fbr_log_id.write(
                                            {'fbr_response': str(r_json),
                                             'posted_succesfull': False})
                                    order.write(
                                        {'fbr_respone': str(r_json), 'fbr_request': json.dumps(order_dic)})
                            # payment_response = requests.post(fbr_url, data=json.dumps(
                            #     order_dic), headers=header, verify=False, timeout=20)
                            # r_json = payment_response.json()
                            # invoice_number = r_json.get('InvoiceNumber')
                            #
                            # if fbr_log_id:
                            #     fbr_log_id.write(
                            #         {'fbr_response': r_json, 'fbr_invoice_number': invoice_number, 'posted_succesfull': True})
                            #
                            # order.write({'fbr_respone': r_json, 'post_data_fbr': True,
                            #              'invoice_number': invoice_number, 'fbr_request': json.dumps(order_dic)})

                except Exception as e:
                    values = dict(
                        exception=e,
                        traceback=traceback.format_exc(),
                    )
                    if fbr_log_id:
                        fbr_log_id.write(
                            {'fbr_response': values, 'posted_succesfull': False})
                    order.write(
                        {'fbr_respone': values, 'fbr_request': json.dumps(order_dic)})

    @api.model
    def _order_fields(self, ui_order):
        res = super(POSOrder, self)._order_fields(ui_order)
        res['invoice_number'] = ui_order.get('invoice_number', False)
        res['post_data_fbr'] = ui_order.get('post_data_fbr', False)
        res['fbr_respone'] = ui_order.get('fbr_respone', False)
        res['fbr_request'] = ui_order.get('fbr_request', False)
        print('\n\n >>> ', ui_order.get('total_discount', 0.00))
        res['total_discount'] = ui_order.get('total_discount', 0.00)
        if ui_order.get('sh_include_service_fee'):
            res['sh_include_service_fee'] = ui_order.get(
                'sh_include_service_fee', False)
            res['sh_service_fee'] = ui_order.get('sh_service_fee', False)
        return res

