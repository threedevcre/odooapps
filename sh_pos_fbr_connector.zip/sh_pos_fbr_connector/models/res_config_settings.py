# Copyright (C) Softhealer Technologies.
# Part of Softhealer Technologies.

from odoo import models, fields, api

class ResConfigSettiongsInhert(models.TransientModel):
    _inherit = "res.config.settings"


    pos_sh_enable_fbr_connector_feature = fields.Boolean(related="pos_config_id.sh_enable_fbr_connector_feature",readonly=False)
    pos_sh_fbr_authentication_type = fields.Selection(related="pos_config_id.sh_fbr_authentication_type",readonly=False)
    pos_pos_id = fields.Char(related="pos_config_id.pos_id",readonly=False)
    pos_fbr_authorization = fields.Char(related="pos_config_id.fbr_authorization",readonly=False)
    pos_sh_receipt_logo = fields.Binary(related="pos_config_id.sh_receipt_logo",readonly=False)
    pos_sh_enable_include_service = fields.Boolean(related="pos_config_id.sh_enable_include_service",readonly=False)
    pos_sh_service_fee = fields.Float(related="pos_config_id.sh_service_fee",readonly=False)
    pos_fbr_url = fields.Char(related="pos_config_id.fbr_url",readonly=False)

    pos_logo_new = fields.Binary(related="pos_config_id.pos_logo_new", readonly=False)
    pos_company_name_new = fields.Char(related="pos_config_id.pos_company_name_new", readonly=False)
    pos_company_address_new = fields.Char(related="pos_config_id.pos_company_address_new", readonly=False)
    pos_company_phone_new = fields.Char(related="pos_config_id.pos_company_phone_new", readonly=False)
    pos_company_email_new = fields.Char(related="pos_config_id.pos_company_email_new", readonly=False)
    pos_company_web_new = fields.Char(related="pos_config_id.pos_company_web_new", readonly=False)

