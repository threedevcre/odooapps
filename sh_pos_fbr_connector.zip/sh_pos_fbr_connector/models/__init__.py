# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from . import pos_config
from . import pos_order
from . import pos_payment_method
from . import pos_session
from . import product_product
from . import res_company
from . import res_config_settings
from . import res_partner
from . import sh_pos_fbr_log
