from odoo import models

class PosConfigInherit(models.Model):
    _inherit = 'pos.config'

    # def _loader_params_res_company(self):
    #     result = super()._loader_params_res_company()
    #     # Add the missing address fields to the 'fields' list
    #     result['search_params']['fields'].extend(['street', 'street2', 'city', 'zip'])
    #     return result

    def _loader_params_pos_config(self):
        result = super()._loader_params_pos_config()
        result['search_params']['fields'].extend([
            'pos_logo_new',
            'pos_company_name_new',
            'pos_company_address_new',
            'pos_company_phone_new',
            'pos_company_email_new',
            'pos_company_web_new'
        ])
        return result