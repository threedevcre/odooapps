# -*- coding: utf-8 -*-

{
    'name': 'POS Gift Receipt Print',
    'version': '17.0.1.0',
    'category': 'Point of Sale',
    'summary': 'Print gift receipts directly from POS in Odoo 17.',
    'description': """
        POS Gift Receipt Print for Odoo 17
        ---------------------------------
        Allows POS users to generate and print gift receipts directly from the POS interface.
    """,
    'author': "NumDesk (Private) Limited",
    'website': "http://www.numdesk.com",
    'license': 'OPL-1',
    'depends': [
        'point_of_sale',
    ],

    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_gift_receipt/static/src/js/**/*',
            'bi_pos_gift_receipt/static/src/xml/**/*',
            'bi_pos_gift_receipt/static/src/css/**/*',
        ],
        'web.assets_backend': [],
    },

    'data': [
        'views/assets.xml',
    ],

    'installable': True,
    'application': False,
    'images': ['static/description/Banner.jpg'],
}
