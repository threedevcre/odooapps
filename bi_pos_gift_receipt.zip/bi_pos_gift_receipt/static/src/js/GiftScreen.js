/** @odoo-module **/

import { Component, useRef } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { useService } from "@web/core/utils/hooks";

export class GiftReceiptPrint extends Component {
    static template = "bi_pos_gift_receipt.GiftReceiptPrint";
    static props = ["data"];
}

export class GiftScreen extends Component {
    static template = "bi_pos_gift_receipt.GiftScreen";

    setup() {
        this.pos = usePos();
        this.printer = useService("printer");
        this.printBtnRef = useRef("gift-print-button");
    }

    back() {
        this.pos.showScreen("ReceiptScreen");
    }

    createNewOrder() {
        this.pos.add_new_order();
        const order = this.pos.get_order();
        if (order && !order.state) {
            order.state = "draft";
        }
        this.pos.showScreen("ProductScreen");
    }

    get receipt() {
        const order = this.pos.get_order();
        const company = this.pos.company || {};
        const config = this.pos.config || {};
        const lines = order ? order.get_orderlines() : [];
        const partner = order ? order.get_partner() : null;
        const dateValue = order && order.validation_date ? order.validation_date : new Date();
        // console.log("street", this.pos.company.street)
        // console.log("street2", this.pos.company.street2)
        // console.log("city", this.pos.company.city)
        // console.log("zip", this.pos.company.zip)
        // console.log("email", this.pos.company.email)
        console.log("date", dateValue.toLocaleString())
        console.log("customer_name", partner ? partner.name : false)
        return {
            company: {
                name: config.pos_company_name_new || "",
                contact_address: config.pos_company_address_new || "",
                phone: config.pos_company_phone_new || "",
                email: config.pos_company_email_new || "",
                website: config.pos_company_web_new || "",
            },

            date: dateValue.toLocaleString(),
            customer_name: partner ? partner.name : false,

            orderlines: lines.map((line, idx) => ({
                uid: idx,
                product: line.product?.display_name || "",
                quantity: line.get_quantity ? line.get_quantity() : line.qty,
            })),
        };
    }

    async printGiftReceipt() {
        const btnEl = this.printBtnRef.el;
        const iconEl = btnEl ? btnEl.querySelector("i.fa") : null;
        if (iconEl) iconEl.classList.add("fa-spin");

        try {
            await this.printer.print(
                GiftReceiptPrint,
                { data: this.receipt },
                { webPrintFallback: true }
            );
        } catch (err) {
            console.error("Failed to print gift receipt:", err);
        } finally {
            if (iconEl) iconEl.classList.remove("fa-spin");
        }
    }
}

registry.category("pos_screens").add("GiftScreen", GiftScreen);
