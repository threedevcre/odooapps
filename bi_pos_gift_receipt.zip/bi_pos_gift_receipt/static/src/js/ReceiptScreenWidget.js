/** @odoo-module **/

import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";
import { TicketScreen } from "@point_of_sale/app/screens/ticket_screen/ticket_screen";
import { patch } from "@web/core/utils/patch";

patch(ReceiptScreen.prototype, {
    openGiftScreen() {
    console.log("Gift Receipt Button ---------------------- ")
        this.pos.showScreen("GiftScreen");
    },
});

const _getStatus = TicketScreen.prototype.getStatus;

patch(TicketScreen.prototype, {
    getStatus(order) {
        let status;
        try {
            status = _getStatus.call(this, order);
        } catch (e) {
            console.warn("[GiftReceipt] TicketScreen.getStatus crashed for order:", order, e);
        }
        if (!status) {
            const state = order?.state || "unknown";
            return { text: state, class: "" };
        }
        return status;
    },
});
