/** @odoo-module **/

import session from "web.session";
import {ringcentralPanel} from "ringcentral.ringcentralPanel";
import {ViewNotFoundError, View} from "@web/views/view";
import {patch} from "@web/core/utils/patch";

var RingcentralPanel =  new ringcentralPanel();
patch(View.prototype, "ringcentral.custom_ringcentral_owl", {
    async loadView(props) {
        await this._super(...arguments);
        var self = this;
        var is_access = await session.user_has_group("ringcentral.ringcentral_user");
        if (is_access) {
            await this.set_ringcentral_sidebar();
            if (this.ringcentralPanel) {
                this.ringcentralPanel.$el.find("#ringcentral_menu").slidemenu();
                this.ringcentralPanel.$el
                    .find("#ring_central_panel_container")
                    .on("click", function () {
                        self.ringcentralPanel.$el
                            .find("#ringcentral_menu")
                            .slideToggle("slow", "linear");
                    });
            }
        }
    },
    set_ringcentral_sidebar() {
        var self = this;
        var base_view = $(".o_web_client");
        $(".nav-tabs a").on("click", function (ev) {
            ev.preventDefault();
            $(ev.currentTarget).tab("show");
        });
        self.ringcentralPanel = RingcentralPanel;
        self.ringcentralPanel.appendTo(base_view);
        session.ringcentralPanel = self.ringcentralPanel;
    },
});
