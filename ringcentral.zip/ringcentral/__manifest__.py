# See LICENSE file for full copyright and licensing details.
{
    # Module Info
    "name": "Odoo RingCentral Integration",
    "version": "16.0.1.0.1",
    "license": "LGPL-3",
    "category": "Customer Relationship Management, Industry",
    "summary": "This is the connector application for RingCentral integration",
    # Author
    "author": "Serpent Consulting Services Pvt. Ltd.",
    "website": "https://www.serpentcs.com",
    # Dependencies
    "depends": ["crm", "sales_team", "project", "web", "account"],
    # Data
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        # "views/template.xml",
        "views/crm_phonecall_view.xml",
        "views/res_users_view.xml",
        "views/company_view.xml",
        "wizard/synch_data_wiz.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "/ringcentral/static/src/lib/sip.js",
            "/ringcentral/static/src/lib/fetch.js",
            "/ringcentral/static/src/lib/promise.js",
            "/ringcentral/static/src/lib/pubnub.js",
            "/ringcentral/static/src/lib/ringcentral.js",
            "/ringcentral/static/src/lib/ringcentral-web-phone.js",
            "/ringcentral/static/src/lib/jquery.slidemenu.js",
            "/ringcentral/static/src/lib/ringcentral_portal_login.js",
            "/ringcentral/static/src/lib/audio_field.js",
            "/ringcentral/static/src/js/custom_ringcentral_owl.js",
            "/ringcentral/static/src/js/custom_ringcentral.js",
            "/ringcentral/static/src/js/list_view.js",
            "/ringcentral/static/src/scss/slidemenu.scss",
            "/ringcentral/static/src/css/ringcentral.css",
            "/ringcentral/static/src/scss/custom_ringcentral.scss",
            "/ringcentral/static/src/xml/list_view.xml",
            "/ringcentral/static/src/xml/ringcentral.xml",
            "/ringcentral/static/src/xml/widget.xml",
            "/ringcentral/static/src/js/phone_field.js",
        ],
    },
    # "qweb": ["static/src/xml/list.xml", "static/src/xml/widget.xml"],
    # Odoo App Store Specific
    "images": ["static/description/RingCentral-Banner.png"],
    "live_test_url": """
                     https://www.youtube.com/watch?v=P_UnbQwf_So&list=PL4Wugt3LKrSQTcPoOEONX0wtc16xtEB1b
                     """,
    # Technical
    "installable": True,
    "application": True,
    "price": 599,
    "currency": "EUR",
}
