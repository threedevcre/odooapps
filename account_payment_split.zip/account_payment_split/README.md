# Account Payment Split – Odoo 17 Custom Module

## What This Module Does

Extends the **Register Payment** popup in Accounting to let you split the
**Payment Difference** across **multiple accounts** with custom amounts.

### Example Scenario

| Invoice Total | Payment Entered | Difference |
|--------------|-----------------|------------|
| 2,000        | 1,000           | 1,000      |

You then add split lines:

| Account        | Amount | Running Remaining |
|----------------|--------|-------------------|
| Write-Off Acc  | 200    | 800               |
| Discount Acc   | 300    | 500               |

Each line posts a separate journal entry to the selected account.  
The "Remaining Difference" is shown live and turns **red** if you over-allocate.

---

## Installation

1. Copy the `account_payment_split/` folder into your Odoo **addons** path, e.g.:
   ```
   /odoo/custom-addons/account_payment_split/
   ```

2. Restart the Odoo server:
   ```bash
   systemctl restart odoo
   # or
   ./odoo-bin --config=/etc/odoo/odoo.conf
   ```

3. Activate **Developer Mode** (Settings → Activate Developer Mode).

4. Go to **Apps**, click **Update Apps List**, search for  
   **"Account Payment Split"** and install it.

---

## How to Use

1. Open a **Customer Invoice** (or Vendor Bill) that has an outstanding balance.
2. Click **Register Payment**.
3. In the popup, enter an amount **less than** the invoice total.  
   → The **Payment Difference** field will show the gap.
4. Select **Mark as Fully Paid** under Payment Difference.
5. A new toggle appears: **Split Difference Across Multiple Accounts**.  
   → Enable it.
6. A table appears. Click **Add a line** and fill in:
   - **Account** – the write-off / discount / income account
   - **Label** – optional memo
   - **Amount** – how much to post to this account
7. Add as many lines as needed.  
   The **Remaining Difference** updates live with every change.
8. Click **Create Payment**.

Odoo will:
- Create the payment for the amount you entered.
- Create one **journal entry per split line**, posting each amount to its account.
- Reconcile everything against the invoice.

---

## Configuration (No-Code Alternatives in Odoo 17)

Odoo 17's built-in **Register Payment** dialog supports only **one** write-off
account per payment. There is **no native configuration** to split across
multiple accounts. This module is therefore required for the multi-account
split behaviour.

However, if you only need a *single* write-off account, the standard
"Mark as Fully Paid → Post Difference In" field is sufficient – no module needed.

---

## File Structure

```
account_payment_split/
├── __init__.py
├── __manifest__.py
├── security/
│   └── ir.model.access.csv          # Access rights for the new transient model
├── wizard/
│   ├── __init__.py
│   ├── account_payment_register.py  # Extended wizard + new WriteOffLine model
│   └── account_payment_register_views.xml  # Extended popup UI
├── models/
│   └── __init__.py
└── static/src/
    ├── js/payment_register_patch.js
    └── xml/payment_register_patch.xml
```

---

## Technical Notes

- The new transient model `account.payment.register.writeoff.line` stores
  the split lines in memory (wizard lifetime only).
- `_get_writeoff_move_vals()` is overridden to suppress Odoo's default
  single write-off entry when split mode is active.
- Each split line creates its own `account.move` (journal entry), posted
  immediately, then reconciled against the invoice's open receivable/payable line.
- Compatible with **Odoo 17 Community and Enterprise**.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Toggle doesn't appear | Ensure "Mark as Fully Paid" is selected AND there is a difference > 0 |
| Lines don't save | Check that Amount > 0 and Account is set on every line |
| Over-allocation error | Remaining Difference turns red; reduce line amounts |
| Module not found | Verify the folder is in the addons path and server was restarted |
