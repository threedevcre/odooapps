# -*- coding: utf-8 -*-
{
    'name': 'Account Payment Split (Multi-Account Write-Off)',
    'version': '17.0.1.5.1',
    'category': 'Accounting/Accounting',
    'summary': 'Split payment difference across multiple accounts with custom amounts',
    'description': """
v1.2.0 – BUG FIXES
• Write-off amounts now correctly post to journal entries and appear
  in the invoice's Journal Items tab.
• Invoice shows green IN PAYMENT / PAID ribbon (not PARTIAL) when
  Remaining Difference = $0.
• "Missing Record" dialog eliminated.

HOW IT WORKS
When you register a payment for less than the invoice total and enable
"Split Difference Across Multiple Accounts", the module:
1. Posts the entered amount as a bank/cash payment.
2. Creates ONE combined write-off journal entry (Miscellaneous journal):
     Dr  Split Account A   $amount_A
     Dr  Split Account B   $amount_B
     Cr  Accounts Receivable  $total
3. Reconciles the write-off A/R line with the invoice's residual,
   fully closing the invoice when Remaining Difference = $0.
    """,
    'author': 'Custom Development',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/account_payment_register_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
