# -*- coding: utf-8 -*-
"""
account_payment_split — v1.5.1
═══════════════════════════════════════════════════════════════════════════════
FIX: "Could not determine the invoice" error in v1.5.0.

ROOT CAUSE
──────────
We were reading invoice IDs from `self._context['active_ids']` and checking
`active_model == 'account.move'`. In Odoo 17's OWL dialog framework the
wizard button call does NOT carry those context keys — the dialog opens with
`active_model = 'account.payment.register'` (the wizard itself), so our check
always returned empty and raised the error.

The correct Odoo 17 way: `account.payment.register` stores the invoice move
lines in `self.line_ids` (a Many2many set when the wizard is opened from an
invoice). Get the invoice IDs from there instead.

COMPLETE FLOW (no super() — single clean transaction)
──────────────────────────────────────────────────────
① Read invoice moves from self.line_ids.mapped('move_id')
② Create account.payment + action_post()
③ Reconcile payment's A/R line with invoice's A/R line
④ Create combined write-off journal entry (Misc journal)
⑤ Reconcile write-off's A/R line with remaining invoice residual
⑥ Navigate to invoice
"""
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class AccountPaymentRegisterWriteOffLine(models.TransientModel):
    _name = 'account.payment.register.writeoff.line'
    _description = 'Payment Register Write-Off Split Line'

    wizard_id = fields.Many2one(
        'account.payment.register', string='Wizard',
        required=True, ondelete='cascade',
    )
    account_id = fields.Many2one(
        'account.account', string='Account', required=True,
        domain="[('deprecated', '=', False)]",
    )
    amount = fields.Monetary(
        string='Amount', required=True, currency_field='currency_id',
    )
    currency_id = fields.Many2one(
        related='wizard_id.currency_id', string='Currency', readonly=True,
    )
    label = fields.Char(string='Label', default='Write-Off')


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    use_split_writeoff = fields.Boolean(
        string='Use Split Write-Off', default=False,
    )
    split_writeoff_line_ids = fields.One2many(
        'account.payment.register.writeoff.line', 'wizard_id',
        string='Write-Off Split Lines',
    )
    split_writeoff_total = fields.Monetary(
        string='Allocated to Accounts', compute='_compute_split_totals',
        currency_field='currency_id', store=False,
    )
    split_remaining_difference = fields.Monetary(
        string='Remaining Difference', compute='_compute_split_totals',
        currency_field='currency_id', store=False,
    )

    @api.depends('split_writeoff_line_ids.amount', 'payment_difference', 'use_split_writeoff')
    def _compute_split_totals(self):
        for wiz in self:
            total = sum(wiz.split_writeoff_line_ids.mapped('amount'))
            wiz.split_writeoff_total = total
            wiz.split_remaining_difference = abs(wiz.payment_difference or 0.0) - total

    def _get_writeoff_move_vals(self):
        """Block Odoo's built-in write-off when split mode is active."""
        if self.use_split_writeoff and self.split_writeoff_line_ids:
            return []
        return super()._get_writeoff_move_vals()

    def _check_split_writeoff(self):
        self.ensure_one()
        if not self.split_writeoff_line_ids:
            raise UserError(_(
                'Split write-off is enabled but no split lines are configured. '
                'Please add at least one account and amount.'
            ))
        for line in self.split_writeoff_line_ids:
            if not line.account_id:
                raise UserError(_('Every split line must have an account selected.'))
            if line.amount <= 0:
                raise UserError(_(
                    'Amount for account "%s" must be greater than zero.',
                    line.account_id.display_name,
                ))
        if self.split_remaining_difference < -0.01:
            raise UserError(_(
                'Total split (%(total).2f) exceeds the payment difference (%(diff).2f).',
                total=self.split_writeoff_total,
                diff=abs(self.payment_difference or 0.0),
            ))

    def _get_invoice_moves(self):
        """
        Return the invoice account.move records being paid.

        In Odoo 17 the wizard stores the move LINES in self.line_ids.
        We derive the parent moves from there.  Context active_ids is
        unreliable — the OWL dialog framework may not pass it.
        """
        # Primary: wizard's own line_ids (always populated in Odoo 17)
        invoice_moves = self.line_ids.mapped('move_id').filtered(
            lambda m: m.move_type in (
                'out_invoice', 'in_invoice', 'out_refund', 'in_refund',
            )
        )
        if invoice_moves:
            return invoice_moves

        # Fallback: context (older Odoo 17 builds or edge cases)
        ctx = self._context
        active_ids   = list(ctx.get('active_ids', []))
        active_model = ctx.get('active_model', '')
        if active_model == 'account.move' and active_ids:
            return self.env['account.move'].browse(active_ids).filtered(
                lambda m: m.move_type in (
                    'out_invoice', 'in_invoice', 'out_refund', 'in_refund',
                )
            )

        return self.env['account.move']

    # =========================================================================
    # MAIN ACTION
    # =========================================================================

    def action_create_payments(self):
        """
        Full manual payment + write-off flow. Does NOT call super().

        Why no super(): Odoo 17 wraps _create_payments() in an internal
        savepoint; any exception in surrounding code rolls back only the
        write-off while the bank payment survives, producing the PARTIAL
        symptom every time. Doing everything manually in one transaction
        removes all savepoint ambiguity.
        """
        if not (self.use_split_writeoff and self.split_writeoff_line_ids):
            return super().action_create_payments()

        self._check_split_writeoff()

        # ── ① Get invoice moves (from self.line_ids, NOT from context) ────────
        invoice_moves = self._get_invoice_moves()
        if not invoice_moves:
            raise UserError(_(
                'Could not find the invoice(s) to pay. '
                'Please register payment directly from the invoice form.'
            ))

        invoice_ids = invoice_moves.ids
        primary_id  = invoice_ids[0]
        move_type   = invoice_moves[:1].move_type
        partner     = self.partner_id
        company     = self.company_id or self.env.company
        currency    = self.currency_id
        journal     = self.journal_id
        payment_date = self.payment_date
        amount       = float(self.amount)

        # A/R or A/P account
        if move_type in ('out_invoice', 'out_refund'):
            counterpart_account_id = partner.property_account_receivable_id.id
        else:
            counterpart_account_id = partner.property_account_payable_id.id

        if not counterpart_account_id:
            raise UserError(_(
                'No receivable/payable account configured for partner "%s".',
                partner.display_name,
            ))

        # Payment direction
        payment_type = 'inbound' if move_type in ('out_invoice', 'in_refund') else 'outbound'
        partner_type = 'customer' if move_type in ('out_invoice', 'out_refund') else 'supplier'

        # Split lines (read while wizard ORM is fully intact)
        split_lines = self.split_writeoff_line_ids.filtered(
            lambda l: l.amount > 0 and l.account_id
        )
        if not split_lines:
            raise UserError(_(
                'No valid split lines found. '
                'Each line needs an account and an amount greater than zero.'
            ))

        _logger.info(
            'account_payment_split v1.5.1: invoice_ids=%s move_type=%s '
            'partner=%s amount=%.2f split_lines=%d counterpart_account=%s',
            invoice_ids, move_type, partner.id, amount,
            len(split_lines), counterpart_account_id,
        )

        # ── ② Create and post the bank/cash payment ───────────────────────────
        payment_vals = {
            'payment_type':  payment_type,
            'partner_type':  partner_type,
            'partner_id':    partner.id,
            'amount':        amount,
            'journal_id':    journal.id,
            'date':          payment_date,
            'currency_id':   currency.id,
            'company_id':    company.id,
        }

        # Include optional wizard fields when present
        if hasattr(self, 'payment_method_line_id') and self.payment_method_line_id:
            payment_vals['payment_method_line_id'] = self.payment_method_line_id.id
        for memo_field in ('communication', 'memo', 'ref'):
            val = getattr(self, memo_field, None)
            if val:
                payment_vals['ref'] = val
                break

        payment = self.env['account.payment'].create(payment_vals)
        payment.action_post()

        _logger.info(
            'account_payment_split v1.5.1: posted payment %s (%.2f)',
            payment.name, amount,
        )

        self.env.flush_all()

        # ── ③ Reconcile bank payment with invoice ─────────────────────────────
        payment_ar_lines = payment.line_ids.filtered(
            lambda l: l.account_id.id == counterpart_account_id and not l.reconciled
        )
        invoice_ar_lines = self.env['account.move.line'].search([
            ('move_id', 'in', invoice_ids),
            ('account_id', '=', counterpart_account_id),
            ('reconciled', '=', False),
            ('parent_state', '=', 'posted'),
        ])

        if payment_ar_lines and invoice_ar_lines:
            (payment_ar_lines + invoice_ar_lines).reconcile()
            _logger.info(
                'account_payment_split v1.5.1: reconciled payment %s with invoices %s',
                payment.name, invoice_ids,
            )
        else:
            _logger.warning(
                'account_payment_split v1.5.1: payment reconciliation skipped — '
                'payment_ar=%s  invoice_ar=%s',
                payment_ar_lines.ids, invoice_ar_lines.ids,
            )

        self.env.flush_all()

        # ── ④ Create combined write-off journal entry (Misc journal) ──────────
        misc_journal = self.env['account.journal'].search(
            [('type', '=', 'general'), ('company_id', '=', company.id)],
            order='id asc', limit=1,
        ) or journal

        total_wo          = sum(float(sl.amount) for sl in split_lines)
        reduce_receivable = move_type in ('out_invoice', 'in_refund')
        wo_line_ids       = []

        for sl in split_lines:
            if reduce_receivable:
                dr, cr = float(sl.amount), 0.0
            else:
                dr, cr = 0.0, float(sl.amount)
            wo_line_ids.append((0, 0, {
                'name':        sl.label or 'Write-Off',
                'account_id':  sl.account_id.id,
                'partner_id':  partner.id,
                'debit':       dr,
                'credit':      cr,
                'currency_id': currency.id,
            }))

        # Single A/R or A/P counterpart line (reconciled with invoice residual)
        if reduce_receivable:
            cp_dr, cp_cr = 0.0, total_wo
        else:
            cp_dr, cp_cr = total_wo, 0.0

        wo_line_ids.append((0, 0, {
            'name':        'Write-Off',
            'account_id':  counterpart_account_id,
            'partner_id':  partner.id,
            'debit':       cp_dr,
            'credit':      cp_cr,
            'currency_id': currency.id,
        }))

        wo_move = self.env['account.move'].create({
            'journal_id': misc_journal.id,
            'date':       payment_date,
            'ref':        'Write-Off — %s' % (partner.name or ''),
            'company_id': company.id,
            'line_ids':   wo_line_ids,
        })
        wo_move.action_post()

        _logger.info(
            'account_payment_split v1.5.1: posted write-off %s '
            '(total=%.2f, %d lines)',
            wo_move.name, total_wo, len(split_lines),
        )

        # Capture write-off's A/R counterpart line ID while cache is fresh
        wo_cp_line = wo_move.line_ids.filtered(
            lambda l: l.account_id.id == counterpart_account_id
        )
        wo_cp_line_id = wo_cp_line[:1].id
        self.env.flush_all()

        # ── ⑤ Reconcile write-off with remaining invoice residual ─────────────
        if wo_cp_line_id:
            self.env.cr.execute("""
                SELECT id FROM account_move_line
                 WHERE move_id     IN %s
                   AND account_id   = %s
                   AND reconciled   = FALSE
                   AND parent_state = 'posted'
                   AND ABS(amount_residual) > 0.001
            """, (tuple(invoice_ids), counterpart_account_id))
            remaining_ids = [r[0] for r in self.env.cr.fetchall()]

            _logger.info(
                'account_payment_split v1.5.1: remaining open A/R ids=%s  '
                'wo_cp_line_id=%s', remaining_ids, wo_cp_line_id,
            )

            if remaining_ids:
                try:
                    self.env['account.move.line'].browse(
                        remaining_ids + [wo_cp_line_id]
                    ).reconcile()
                    _logger.info(
                        'account_payment_split v1.5.1: write-off reconciliation '
                        'OK for invoices %s', invoice_ids,
                    )
                except Exception as exc:
                    _logger.error(
                        'account_payment_split v1.5.1: write-off reconciliation '
                        'FAILED: %s', exc,
                    )
                    raise UserError(_(
                        'Write-off move %s posted but reconciliation failed:\n%s\n\n'
                        'Bank payment is saved. Reconcile write-off manually '
                        'from the journal items.',
                        wo_move.name, str(exc),
                    )) from exc

        # ── ⑥ Navigate to the invoice (fresh load — avoids Missing Record) ────
        return {
            'type': 'ir.actions.client',
            'tag':  'display_notification',
            'params': {
                'title':   _('Payment Registered'),
                'message': _('Bank payment and write-off posted successfully.'),
                'sticky':  False,
                'type':    'success',
                'next': {
                    'type':      'ir.actions.act_window',
                    'res_model': 'account.move',
                    'res_id':    primary_id,
                    'view_mode': 'form',
                    'views':     [(False, 'form')],
                    'target':    'main',
                },
            },
        }
